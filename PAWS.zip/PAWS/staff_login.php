<?php
session_start();

include("connection.php");
include("includes/flash.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if ($username == "" || $password == "") {
        $message = "Please enter username and password.";
    } else {

        $sql = "SELECT * FROM staff WHERE username = ?";
        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            die("SQL Prepare Error: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) == 1) {

            $row = mysqli_fetch_assoc($result);

            if (password_verify($password, $row['password'])) {

                session_regenerate_id(true);

                unset($_SESSION['adopter_id']);
                unset($_SESSION['adopter_name']);

                $_SESSION['staff_id'] = $row['staff_id'];
                $_SESSION['staff_name'] = $row['full_name'];
                $_SESSION['user_type'] = "staff";

                setFlashMessage("success", "Staff login successful! Welcome to PAWS Staff Portal.");
                header("Location: staff/dashboard.php");
                exit();

            } else {
                $message = "Invalid username or password.";
            }

        } else {
            $message = "Invalid username or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Staff Login | PAWS</title>
    <link rel="stylesheet" href="css/dashboard.css?v=10">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="images/paws-logo.png" alt="PAWS Logo">
        <span>Staff Login</span>
    </div>

    <a href="index.php" class="header-link">Home</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card">
            <h2>Login as Staff</h2>

            <div class="notice-box">
                Staff access is used to manage pets, appointments, and adoption applications.
            </div>

            <?php
            if ($message != "") {
                echo "<div class='error-box'>$message</div>";
            }
            ?>

            <form method="POST">

                <label>Username</label>
                <input 
                    type="text" 
                    name="username" 
                    placeholder="Enter staff username"
                    required
                >

                <label>Password</label>
                <input 
                    type="password" 
                    name="password" 
                    placeholder="Enter staff password"
                    required
                >

                <button type="submit" class="btn">Login</button>

            </form>
        </div>

    </div>
</section>

<script src="js/ui-feedback.js"></script>

</body>
</html>