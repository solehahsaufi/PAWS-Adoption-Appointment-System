<?php
session_start();

include("connection.php");
include("includes/flash.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if ($email == "" || $password == "") {
        $message = "Please enter email and password.";
    } else {

        $sql = "SELECT * FROM adopter WHERE email = ?";
        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            die("SQL Prepare Error: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) == 1) {

            $row = mysqli_fetch_assoc($result);

            if (password_verify($password, $row['password'])) {

                session_regenerate_id(true);

                unset($_SESSION['staff_id']);
                unset($_SESSION['staff_name']);

                $_SESSION['adopter_id'] = $row['adopter_id'];
                $_SESSION['adopter_name'] = $row['full_name'];
                $_SESSION['user_type'] = "adopter";

                setFlashMessage("success", "Login successful! Welcome to PAWS Adoption System.");
                header("Location: adopter/dashboard.php");
                exit();

            } else {
                $message = "Invalid email or password.";
            }

        } else {
            $message = "Invalid email or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Adopter Login | PAWS</title>
    <link rel="stylesheet" href="css/dashboard.css?v=10">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="images/paws-logo.png" alt="PAWS Logo">
        <span>Adopter Login</span>
    </div>

    <a href="index.php" class="header-link">Home</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card">
            <h2>Login as Adopter</h2>

            <div class="notice-box">
                Login to book adoption appointments and manage your adoption applications.
            </div>

            <?php
            if ($message != "") {
                echo "<div class='error-box'>$message</div>";
            }
            ?>

            <form method="POST">

                <label>Email Address</label>
                <input 
                    type="email" 
                    name="email" 
                    placeholder="Enter your email address"
                    required
                >

                <label>Password</label>
                <input 
                    type="password" 
                    name="password" 
                    placeholder="Enter your password"
                    required
                >

                <button type="submit" class="btn">Login</button>

            </form>

            <p style="text-align:center; margin-top:12px;">
                <a href="forgot_password.php" style="color:#1d4ed8; font-weight:600;">
                    Forgot Password?
                </a>
            </p>

            <p style="text-align:center; margin-top:12px;">
                Do not have an account?
                <a href="register.php" style="color:#1d4ed8; font-weight:600;">
                    Register here
                </a>
            </p>
        </div>

    </div>
</section>

<script src="js/ui-feedback.js"></script>

</body>
</html>