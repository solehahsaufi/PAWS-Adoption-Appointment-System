-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Jul 02, 2026 at 08:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paws_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `adopter`
--

CREATE TABLE `adopter` (
  `adopter_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `unit_no` varchar(50) DEFAULT NULL,
  `building_name` varchar(150) DEFAULT NULL,
  `street` varchar(150) DEFAULT NULL,
  `area` varchar(150) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `preferred_pet_type` varchar(30) DEFAULT NULL,
  `preferred_pet_age` varchar(30) DEFAULT NULL,
  `home_environment` varchar(30) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT 'default.png',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adopter`
--

INSERT INTO `adopter` (`adopter_id`, `full_name`, `gender`, `profile_image`, `email`, `phone`, `unit_no`, `building_name`, `street`, `area`, `postcode`, `city`, `state`, `password`, `address`, `preferred_pet_type`, `preferred_pet_age`, `home_environment`, `profile_picture`, `created_at`) VALUES
(1, 'caca', NULL, NULL, 'ca@gmail.com', '0178967453', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '$2y$10$MjurLbBGE9NrOGuFCJMbKeyf3sxviDGk7o6YFFXRtXKb7H4tx0lKa', 'Klang, Selangor', NULL, NULL, NULL, 'default.png', '2026-07-01 15:11:25'),
(3, 'abu', 'Male', '', 'abu@gmail.com', '019-4433220', NULL, NULL, NULL, NULL, '56000', 'Cheras', 'Kuala Lumpur', '$2y$10$aCnkftW4PtALUOhPuNAU.uj/n45bAoc6ctjfEVlgNGsCnga.v2TkO', 'Lot 1546, Jalan Comel, Taman Indah, Ampang, Selangor, 56000 Cheras, Kuala Lumpur', 'Cat', 'Kitten/Puppy', 'Indoor', 'default.png', '2026-07-02 05:51:12'),
(4, 'bibi', 'Female', '1782980403_images.jpg', 'bibi@gmail.com', '019-8989890', 'NO 13', '', 'Jalan Bahagia', 'Taman Seri Cemerlang', '43800', 'Dengkil', 'Selangor', '$2y$10$lCEHnvKLs3y0jIuLzqSAz.9BkP1xzyGj.ppZtpGtx/ah87VkTMKLG', 'NO 13, Jalan Bahagia, Taman Seri Cemerlang, 43800 Dengkil, Selangor', 'Cat', 'Kitten/Puppy', 'Indoor', 'default.png', '2026-07-02 07:31:27'),
(5, 'Niaa', NULL, NULL, 'nia@gmail.com', '018-9090786', 'C-10-06', 'Blok A, Cybersky', 'Jalan Berjaya', '-', '40000', 'Shah Alam', 'Selangor', '$2y$10$9KUxm3dakSEisJuwnJx8fekOPb673iTArndgi1sl6SuOC1BoREuTm', 'C-10-06, Blok A, Cybersky, Jalan Berjaya, -, 40000 Shah Alam, Selangor', NULL, NULL, NULL, 'default.png', '2026-07-02 11:31:04'),
(6, 'nini', 'Female', '', 'nini@gmail.com', '012-7878900', '', '', '', '', '43300', 'Seri Kembangan', 'Selangor', '$2y$10$cFTtEOHGJUKJUUFZ9dn0d.dEtvmm9Oco5OIxHHxBA3Q/d/pNAyyKu', 'No 3 Jalan Selamat, 43300 Seri Kembangan, Selangor, 43300 Seri Kembangan, Selangor', 'Cat', 'Adult', 'Outdoor', 'default.png', '2026-07-02 12:01:58'),
(7, 'Wawa', NULL, '1783016066_images__2_.jpg', 'wawa@gmail.com', '017-8899007', '', '', '', '', '47000', 'Sungai Buloh', 'Selangor', '$2y$10$I748USAJiWZB/Hha71kOaueH7YrNrhWmjKaydkyzw.ipHhncyTbRS', 'KG Kumbang, 47000 Sungai Buloh, Selangor', 'Cat', 'Baby', 'Apartment', 'default.png', '2026-07-02 17:30:58');

-- --------------------------------------------------------

--
-- Table structure for table `adoption_application`
--

CREATE TABLE `adoption_application` (
  `application_id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `adopter_id` int(11) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `application_date` date NOT NULL,
  `reason` text DEFAULT NULL,
  `housing_type` varchar(100) DEFAULT NULL,
  `pet_experience` varchar(100) DEFAULT NULL,
  `current_pets` varchar(100) DEFAULT NULL,
  `family_agreement` varchar(50) DEFAULT NULL,
  `vet_agreement` varchar(50) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adoption_application`
--

INSERT INTO `adoption_application` (`application_id`, `appointment_id`, `adopter_id`, `pet_id`, `application_date`, `reason`, `housing_type`, `pet_experience`, `current_pets`, `family_agreement`, `vet_agreement`, `status`, `remarks`) VALUES
(4, 10, 7, 2, '2026-07-03', 'because she reminds me of my grandmother', 'Apartment', 'No experience', 'No current pets', 'Yes', 'Yes', 'Approved', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appointment_id` int(11) NOT NULL,
  `adopter_id` int(11) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `appointment_reason` varchar(255) DEFAULT NULL,
  `appointment_notes` text DEFAULT NULL,
  `purpose` varchar(100) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected','Completed','Cancelled') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appointment_id`, `adopter_id`, `pet_id`, `appointment_date`, `appointment_time`, `appointment_reason`, `appointment_notes`, `purpose`, `status`, `created_at`) VALUES
(6, 3, 10, '2026-07-09', '12:00:00', '', NULL, NULL, 'Pending', '2026-07-02 05:51:50'),
(7, 4, 11, '2026-07-05', '09:00:00', '', NULL, NULL, 'Approved', '2026-07-02 09:46:23'),
(8, 3, 1, '2026-07-05', '10:00:00', '', NULL, NULL, 'Approved', '2026-07-02 13:25:39'),
(9, 6, 8, '2026-07-05', '12:00:00', 'Meet the pet before adoption', '', NULL, 'Pending', '2026-07-02 14:52:58'),
(10, 7, 2, '2026-07-07', '12:00:00', 'Meet the pet before adoption', '', NULL, 'Completed', '2026-07-02 18:15:40');

-- --------------------------------------------------------

--
-- Table structure for table `pet`
--

CREATE TABLE `pet` (
  `pet_id` int(11) NOT NULL,
  `pet_name` varchar(100) NOT NULL,
  `species` varchar(50) NOT NULL,
  `breed` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `age` int(11) NOT NULL,
  `estimated_birth_date` date DEFAULT NULL,
  `vaccination` varchar(50) NOT NULL DEFAULT 'Not Completed',
  `colour` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('Available','Booked','Adopted') DEFAULT 'Available',
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pet`
--

INSERT INTO `pet` (`pet_id`, `pet_name`, `species`, `breed`, `gender`, `age`, `estimated_birth_date`, `vaccination`, `colour`, `description`, `status`, `image`) VALUES
(1, 'Jessica', 'Cat', 'Maine Coon', 'Female', 29, '2024-01-07', 'Completed', NULL, 'Calm, friendly, and suitable for families.', 'Booked', '1782921391_Maine Coon.jpg'),
(2, 'Lily', 'Cat', 'Persian', 'Female', 19, '2024-11-21', 'Completed', NULL, 'Gentle indoor cat that loves attention.', 'Adopted', '1782921538_persian.jpg'),
(3, 'Daisy', 'Dog', 'Poodle', 'Female', 6, '2026-01-02', 'Completed', NULL, 'Friendly, clean, and easy to train.', 'Available', '1782921635_poodle.jpg'),
(4, 'Oreo', 'Cat', 'Domestic Long Hair', 'Male', 7, '2025-11-30', 'Not Completed', NULL, 'Cute kitten with black and white fur, playful and active.', 'Adopted', '1782921784_Domestic-Longhair-3_600x600.webp'),
(5, 'Mimi', 'Cat', 'Siamese', 'Female', 24, '2024-07-02', 'Completed', NULL, 'Smart and vocal cat that enjoys human interaction.', 'Booked', '1782921919_siamese.webp'),
(6, 'Max', 'Dog', 'Beagle', 'Male', 5, '2026-01-26', 'Not Completed', NULL, 'Cheerful dog that enjoys walking and outdoor activities.', 'Available', '1782922021_beagle.jpg'),
(7, 'Alpha', 'Dog', 'Labrador Retriever', 'Male', 18, '2024-12-31', 'Not Completed', NULL, 'An energetic puppy that enjoys playing.', 'Available', '1782922179_labrador.jpg'),
(8, 'Milo', 'Dog', 'Chihuahua', 'Male', 12, '2025-06-30', 'Not Completed', NULL, 'Small and active dog, suitable for indoor living.', 'Booked', '1782922280_chihuahua.jpg'),
(9, 'Koko', 'Cat', 'British Shorthair', 'Male', 36, '2023-06-27', 'Completed', NULL, 'Quiet, clean, and easy to care for.', 'Booked', '1782922415_bsh.jpg'),
(10, 'Ali', 'Cat', 'Domestic Short Hair', 'Male', 5, '2026-01-04', 'Completed', NULL, 'Playful cat with a curious personality.', 'Booked', '1782922604_dsh.jpg'),
(11, 'Cooper', 'Dog', 'Golden Retriever', 'Male', 17, '2025-01-31', 'Completed', NULL, 'Known for his beautiful golden coats and friendly, good-natured personalities.', 'Booked', '1782966138_goldenretriever.jpg'),
(15, 'Mochi', 'Cat', 'Domestic Short Hair', 'Female', 24, '2024-07-02', 'Completed', NULL, 'A quiet and gentle cat that enjoys resting in calm spaces.', 'Available', '1783007929_mochi.webp'),
(16, 'Bruno', 'Dog', 'Mixed Breed', 'Male', 28, '2024-02-14', 'Completed', NULL, 'A loyal and friendly dog that enjoys walks and human attention.', 'Available', '1783008085_bruno.jpg'),
(17, 'Daisy Mae', 'Dog', 'Poodle Mix', 'Female', 11, '2025-07-03', 'Not Completed', NULL, 'A small and friendly dog suitable for indoor living', 'Available', '1783009897_daisy_mae.jpg'),
(18, 'Salem', 'Cat', 'Black Cat', 'Male', 30, '2023-12-14', 'Completed', NULL, 'An independent cat that is calm and easy to manage.', 'Available', '1783010070_Salem.jpg'),
(19, 'Peanut', 'Cat', 'Domestic Long Hair', 'Male', 42, '2023-01-01', 'Completed', NULL, 'A playful cat that likes toys and interaction with people.', 'Available', '1783010227_peanut.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `full_name`, `profile_image`, `username`, `password`, `role`) VALUES
(1, 'PAWS Staff', '1783012666_images (1).jpg', 'staff', '$2y$10$RMp5KFnWuLsaRGywH8EmAOOfRiq1ld5iDbHKxREECN0nuAb5brbmK', 'Staff');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adopter`
--
ALTER TABLE `adopter`
  ADD PRIMARY KEY (`adopter_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `adoption_application`
--
ALTER TABLE `adoption_application`
  ADD PRIMARY KEY (`application_id`),
  ADD KEY `fk_application_appointment` (`appointment_id`),
  ADD KEY `fk_application_adopter` (`adopter_id`),
  ADD KEY `fk_application_pet` (`pet_id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `fk_appointment_adopter` (`adopter_id`),
  ADD KEY `fk_appointment_pet` (`pet_id`);

--
-- Indexes for table `pet`
--
ALTER TABLE `pet`
  ADD PRIMARY KEY (`pet_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adopter`
--
ALTER TABLE `adopter`
  MODIFY `adopter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `adoption_application`
--
ALTER TABLE `adoption_application`
  MODIFY `application_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `pet`
--
ALTER TABLE `pet`
  MODIFY `pet_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `adoption_application`
--
ALTER TABLE `adoption_application`
  ADD CONSTRAINT `fk_application_adopter` FOREIGN KEY (`adopter_id`) REFERENCES `adopter` (`adopter_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_application_appointment` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`appointment_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_application_pet` FOREIGN KEY (`pet_id`) REFERENCES `pet` (`pet_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `fk_appointment_adopter` FOREIGN KEY (`adopter_id`) REFERENCES `adopter` (`adopter_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_appointment_pet` FOREIGN KEY (`pet_id`) REFERENCES `pet` (`pet_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
