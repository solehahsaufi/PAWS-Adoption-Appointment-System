<!DOCTYPE html>
<html>
<head>
    <title>PAWS Adoption Appointment System</title>
    <link rel="stylesheet" href="css/dashboard.css?v=20">
</head>

<body>

<div class="top-header">
    <div class="brand">
        <img src="images/paws-logo.png" alt="PAWS Logo">
        <span>PAWS Adoption Appointment System</span>
    </div>

    <div style="display:flex; gap:10px; align-items:center;">
        <a href="index.php" class="header-link">Home</a>
        <a href="login.php" class="header-link">Login</a>
        <a href="register.php" class="header-link">Register</a>
    </div>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="dashboard-hero">
            <div class="dashboard-hero-content">

                <span class="dashboard-hero-badge">
                    Welcome to PAWS
                </span>

                <h1>PAWS Adoption Appointment System</h1>

                <p>
                    PAWS Adoption Appointment System helps adopters browse available cats and dogs, 
                    book adoption appointments, submit adoption applications, and track their adoption 
                    progress online in a more convenient and organised way.
                </p>

                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <a href="register.php" class="btn">Register as Adopter</a>
                    <a href="login.php" class="btn btn-light">Adopter Login</a>
                </div>

            </div>
        </div>

        <div class="page-title">
            <h1>Start Your Adoption Journey</h1>
            <p>Register or login to browse pets, book appointments, and track your adoption process.</p>
        </div>

        <div class="dashboard-action-grid">

            <div class="dashboard-action-card">
                <h3>Browse Available Pets</h3>
                <p>
                    View cats and dogs that are currently available for adoption after logging in as an adopter.
                </p>
                <a href="login.php" class="btn">Browse Pets</a>
            </div>

            <div class="dashboard-action-card">
                <h3>Book Appointment</h3>
                <p>
                    Select your preferred pet first, then request an adoption appointment based on available slots.
                </p>
                <a href="login.php" class="btn">Book Appointment</a>
            </div>

            <div class="dashboard-action-card">
                <h3>Track Application</h3>
                <p>
                    Check your appointment approval status and adoption application result through your dashboard.
                </p>
                <a href="login.php" class="btn">Track Status</a>
            </div>

        </div>

    </div>
</section>

<script src="js/ui-feedback.js"></script>

</body>
</html>