<?php
include("../includes/session.php");
checkAdopter();

include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];
$message = "";

if (!isset($_GET['appointment_id'])) {
    setFlashMessage("error", "Invalid appointment record.");
    header("Location: my_appointments.php");
    exit();
}

$appointment_id = intval($_GET['appointment_id']);

/* Get approved appointment details */
$sql = "SELECT 
            appointment.*,
            TIME_FORMAT(appointment.appointment_time, '%H:%i') AS formatted_time,
            pet.pet_name,
            pet.species,
            pet.breed,
            pet.image
        FROM appointment
        INNER JOIN pet ON appointment.pet_id = pet.pet_id
        WHERE appointment.appointment_id = ?
        AND appointment.adopter_id = ?";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "ii", $appointment_id, $adopter_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    setFlashMessage("error", "Appointment record not found.");
    header("Location: my_appointments.php");
    exit();
}

$appointment = mysqli_fetch_assoc($result);

/* IMPORTANT: Application can be submitted after appointment is Approved */
if ($appointment['status'] != "Approved") {
    setFlashMessage("error", "You can only submit an application after the appointment is approved by staff.");
    header("Location: my_appointments.php");
    exit();
}

/* Check if application already exists */
$check_sql = "SELECT application_id 
              FROM adoption_application 
              WHERE appointment_id = ?
              AND adopter_id = ?";

$check_stmt = mysqli_prepare($conn, $check_sql);

if (!$check_stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($check_stmt, "ii", $appointment_id, $adopter_id);
mysqli_stmt_execute($check_stmt);

$check_result = mysqli_stmt_get_result($check_stmt);

if (mysqli_num_rows($check_result) > 0) {
    setFlashMessage("warning", "You have already submitted an application for this appointment.");
    header("Location: application_status.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $housing_type = trim($_POST['housing_type']);
    $pet_experience = trim($_POST['pet_experience']);
    $current_pets = trim($_POST['current_pets']);
    $family_agreement = trim($_POST['family_agreement']);
    $vet_agreement = trim($_POST['vet_agreement']);
    $reason = trim($_POST['reason']);

    if (
        $housing_type == "" ||
        $pet_experience == "" ||
        $current_pets == "" ||
        $family_agreement == "" ||
        $vet_agreement == "" ||
        $reason == ""
    ) {
        $message = "Please fill in all required fields.";
    } elseif ($family_agreement != "Yes" && $family_agreement != "No") {
        $message = "Please select a valid family agreement answer.";
    } elseif ($vet_agreement != "Yes" && $vet_agreement != "No") {
        $message = "Please select a valid veterinary care agreement answer.";
    } else {

        $pet_id = $appointment['pet_id'];

        $insert = "INSERT INTO adoption_application
                   (appointment_id, adopter_id, pet_id, application_date, housing_type, pet_experience, current_pets, family_agreement, vet_agreement, reason, status)
                   VALUES (?, ?, ?, NOW(), ?, ?, ?, ?, ?, ?, 'Pending')";

        $insert_stmt = mysqli_prepare($conn, $insert);

        if (!$insert_stmt) {
            die("SQL Prepare Error: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param(
            $insert_stmt,
            "iiissssss",
            $appointment_id,
            $adopter_id,
            $pet_id,
            $housing_type,
            $pet_experience,
            $current_pets,
            $family_agreement,
            $vet_agreement,
            $reason
        );

        if (mysqli_stmt_execute($insert_stmt)) {
            setFlashMessage("success", "Adoption application submitted successfully! Please wait for staff review.");
            header("Location: application_status.php");
            exit();
        } else {
            die("SQL Execute Error: " . mysqli_stmt_error($insert_stmt));
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Submit Adoption Application | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Submit Adoption Application</span>
    </div>

    <a href="my_appointments.php" class="header-link">Back to My Appointments</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="page-title">
            <h1>Submit Adoption Application</h1>
            <p>Complete the form below to apply for adoption after your appointment request has been approved.</p>
        </div>

        <?php
        if ($message != "") {
            echo "<div class='error-box'>" . htmlspecialchars($message) . "</div>";
        }
        ?>

        <div class="form-card" style="width:760px;">

            <h2>Selected Pet</h2>

            <div class="table-card" style="margin-bottom:25px;">
                <table>
                    <tr>
                        <th>Information</th>
                        <th>Details</th>
                    </tr>

                    <tr>
                        <td>Pet Name</td>
                        <td><?php echo htmlspecialchars($appointment['pet_name']); ?></td>
                    </tr>

                    <tr>
                        <td>Species</td>
                        <td><?php echo htmlspecialchars($appointment['species']); ?></td>
                    </tr>

                    <tr>
                        <td>Breed</td>
                        <td><?php echo htmlspecialchars($appointment['breed']); ?></td>
                    </tr>

                    <tr>
                        <td>Appointment Date</td>
                        <td><?php echo date("d M Y", strtotime($appointment['appointment_date'])); ?></td>
                    </tr>

                    <tr>
                        <td>Appointment Time</td>
                        <td><?php echo date("h:i A", strtotime($appointment['formatted_time'])); ?></td>
                    </tr>

                    <tr>
                        <td>Appointment Status</td>
                        <td><span class="status status-approved">Approved</span></td>
                    </tr>
                </table>
            </div>

            <h2>Application Form</h2>

            <div class="notice-box">
                Please provide honest information. Staff will review your application before making the final adoption decision.
            </div>

            <form method="POST" data-confirm-submit="Are you sure you want to submit this adoption application?">

                <label>Housing Type</label>
                <select name="housing_type" required>
                    <option value="">Select housing type</option>
                    <option value="Apartment">Apartment</option>
                    <option value="Terrace House">Terrace House</option>
                    <option value="Semi-D House">Semi-D House</option>
                    <option value="Bungalow">Bungalow</option>
                    <option value="Other">Other</option>
                </select>

                <label>Pet Experience</label>
                <select name="pet_experience" required>
                    <option value="">Select pet experience</option>
                    <option value="No experience">No experience</option>
                    <option value="Beginner">Beginner</option>
                    <option value="Experienced">Experienced</option>
                    <option value="Very experienced">Very experienced</option>
                </select>

                <label>Current Pets at Home</label>
                <textarea 
                    name="current_pets"
                    placeholder="Example: No current pets / 1 cat / 2 dogs"
                    required></textarea>

                <label>Does your family agree with this adoption?</label>
                <select name="family_agreement" required>
                    <option value="">Select answer</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>

                <label>Are you willing to provide proper veterinary care?</label>
                <select name="vet_agreement" required>
                    <option value="">Select answer</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>

                <label>Reason for Adoption</label>
                <textarea 
                    name="reason"
                    placeholder="Explain why you want to adopt this pet"
                    required></textarea>

                <button type="submit" class="btn">Submit Application</button>

            </form>

        </div>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>