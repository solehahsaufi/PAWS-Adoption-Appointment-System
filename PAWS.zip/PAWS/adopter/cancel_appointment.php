<?php
include("../includes/session.php");
checkAdopter();
include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];

if (!isset($_GET['id'])) {
    setFlashMessage("error", "Invalid appointment record.");
    header("Location: history.php");
    exit();
}

$appointment_id = $_GET['id'];

// Check appointment belongs to adopter and still scheduled
$sql = "SELECT * FROM appointment
        WHERE appointment_id = ?
        AND adopter_id = ?
        AND status IN ('Pending','Approved')";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $appointment_id, $adopter_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    setFlashMessage("error", "This appointment cannot be cancelled.");
    header("Location: history.php");
    exit();
}

$appointment = mysqli_fetch_assoc($result);
$pet_id = $appointment['pet_id'];

mysqli_begin_transaction($conn);

// Update appointment status
$update_appointment = "UPDATE appointment
                       SET status = 'Cancelled'
                       WHERE appointment_id = ?
                       AND adopter_id = ?";

$stmt_update = mysqli_prepare($conn, $update_appointment);
mysqli_stmt_bind_param($stmt_update, "ii", $appointment_id, $adopter_id);
$ok1 = mysqli_stmt_execute($stmt_update);

// Make pet available again
$update_pet = "UPDATE pet
               SET status = 'Available'
               WHERE pet_id = ?";

$stmt_pet = mysqli_prepare($conn, $update_pet);
mysqli_stmt_bind_param($stmt_pet, "i", $pet_id);
$ok2 = mysqli_stmt_execute($stmt_pet);

if ($ok1 && $ok2) {
    mysqli_commit($conn);
    setFlashMessage("success", "Appointment cancelled successfully.");
    header("Location: history.php");
    exit();
} else {
    mysqli_rollback($conn);
    setFlashMessage("error", "Failed to cancel appointment.");
    header("Location: history.php");
    exit();
}
?>