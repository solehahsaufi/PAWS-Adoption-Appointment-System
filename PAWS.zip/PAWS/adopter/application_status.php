<?php
include("../includes/session.php");
checkAdopter();

include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];

$sql = "SELECT 
            adoption_application.*,
            pet.pet_name,
            pet.species,
            pet.breed,
            appointment.appointment_date
        FROM adoption_application
        INNER JOIN pet ON adoption_application.pet_id = pet.pet_id
        INNER JOIN appointment ON adoption_application.appointment_id = appointment.appointment_id
        WHERE adoption_application.adopter_id = ?
        ORDER BY adoption_application.application_date DESC";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $adopter_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Application Status | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=10">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Application Status</span>
    </div>

    <a href="dashboard.php" class="header-link">Back to Dashboard</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="page-title">
            <h1>Application Status</h1>
            <p>Track the status of your submitted adoption applications.</p>
        </div>

        <?php if (mysqli_num_rows($result) == 0) { ?>

            <div class="empty-box">
                <h3>No Application Submitted</h3>
                <p>
                    You have not submitted any adoption application yet.
                    Please complete an appointment first before submitting an application.
                </p>
                <a href="my_appointments.php" class="btn">View My Appointments</a>
            </div>

        <?php } else { ?>

            <div class="table-card">

                <table>
                    <tr>
                        <th>Pet</th>
                        <th>Application Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>

                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>

                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($row['pet_name']); ?></strong>
                                <br>
                                <small>
                                    <?php echo htmlspecialchars($row['species']); ?> |
                                    <?php echo htmlspecialchars($row['breed']); ?>
                                </small>
                            </td>

                            <td>
                                <?php echo date("d M Y", strtotime($row['application_date'])); ?>
                            </td>

                            <td>
                                <?php if ($row['status'] == "Pending") { ?>

                                    <span class="status status-pending">Pending</span>

                                <?php } elseif ($row['status'] == "Approved") { ?>

                                    <span class="status status-approved">Approved</span>

                                <?php } elseif ($row['status'] == "Rejected") { ?>

                                    <span class="status status-rejected">Rejected</span>

                                <?php } else { ?>

                                    <span class="status">
                                        <?php echo htmlspecialchars($row['status']); ?>
                                    </span>

                                <?php } ?>
                            </td>

                            <td>
                                <a 
                                    href="view_application.php?id=<?php echo $row['application_id']; ?>" 
                                    class="btn"
                                >
                                    View Details
                                </a>
                            </td>
                        </tr>

                    <?php } ?>

                </table>

            </div>

        <?php } ?>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>