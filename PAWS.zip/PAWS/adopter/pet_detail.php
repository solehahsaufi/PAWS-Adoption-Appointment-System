<?php
include("../includes/session.php");
checkAdopter();

include("../connection.php");
include("../includes/flash.php");

if (!isset($_GET['id'])) {
    setFlashMessage("error", "Invalid pet record.");
    header("Location: pets.php");
    exit();
}

$pet_id = intval($_GET['id']);

function displayPetAge($birth_date, $fallback_age)
{
    if (!empty($birth_date)) {
        $birthDate = new DateTime($birth_date);
        $today = new DateTime();

        $diff = $birthDate->diff($today);
        $months = ($diff->y * 12) + $diff->m;

        if ($months < 1) {
            return "Less than 1 month";
        } elseif ($months == 1) {
            return "1 month";
        } elseif ($months < 12) {
            return $months . " months";
        } else {
            $years = floor($months / 12);
            $remainingMonths = $months % 12;

            if ($remainingMonths == 0) {
                return $years . ($years == 1 ? " year" : " years");
            }

            return $years . ($years == 1 ? " year " : " years ") . $remainingMonths . ($remainingMonths == 1 ? " month" : " months");
        }
    }

    return htmlspecialchars($fallback_age) . " months";
}

$sql = "SELECT * FROM pet WHERE pet_id = ?";
$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $pet_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    setFlashMessage("error", "Pet record not found.");
    header("Location: pets.php");
    exit();
}

$pet = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Pet Details | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Pet Details</span>
    </div>

    <a href="pets.php" class="header-link">Back to Pets</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card" style="width:720px;">

            <h2><?php echo htmlspecialchars($pet['pet_name']); ?></h2>

            <?php if (!empty($pet['image'])) { ?>
                <img 
                    src="../images/pets/<?php echo htmlspecialchars($pet['image']); ?>" 
                    alt="Pet Image"
                    style="width:100%; max-height:360px; object-fit:cover; border-radius:22px; margin-bottom:22px;"
                >
            <?php } ?>

            <div class="table-card">
                <table>
                    <tr>
                        <th>Information</th>
                        <th>Details</th>
                    </tr>

                    <tr>
                        <td>Species</td>
                        <td><?php echo htmlspecialchars($pet['species']); ?></td>
                    </tr>

                    <tr>
                        <td>Breed</td>
                        <td><?php echo htmlspecialchars($pet['breed']); ?></td>
                    </tr>

                    <tr>
                        <td>Gender</td>
                        <td><?php echo htmlspecialchars($pet['gender']); ?></td>
                    </tr>

                    <tr>
                        <td>Age</td>
                        <td><?php echo displayPetAge($pet['estimated_birth_date'] ?? "", $pet['age']); ?></td>
                    </tr>

                    <tr>
                        <td>Vaccination</td>
                        <td><?php echo htmlspecialchars($pet['vaccination']); ?></td>
                    </tr>

                    <tr>
                        <td>Status</td>
                        <td>
                            <?php if ($pet['status'] == "Available") { ?>
                                <span class="status status-approved">Available</span>
                            <?php } elseif ($pet['status'] == "Booked") { ?>
                                <span class="status status-pending">Booked</span>
                            <?php } elseif ($pet['status'] == "Adopted") { ?>
                                <span class="status status-rejected">Adopted</span>
                            <?php } ?>
                        </td>
                    </tr>
                </table>
            </div>

            <h3 class="profile-section-title">Description</h3>

            <p style="line-height:1.8; color:#374151; margin-bottom:22px;">
                <?php echo nl2br(htmlspecialchars($pet['description'] ?? "No description available.")); ?>
            </p>

            <?php if ($pet['status'] == "Available") { ?>

                <a href="appointment.php?pet_id=<?php echo $pet['pet_id']; ?>" class="btn">
                    Book Appointment
                </a>

            <?php } else { ?>

                <div class="notice-box">
                    This pet is currently not available for appointment booking.
                </div>

            <?php } ?>

        </div>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>