<?php
include("../includes/session.php");
checkAdopter();

include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];
$message = "";
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : "profile";

$sql = "SELECT * FROM adopter WHERE adopter_id = ?";
$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $adopter_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    setFlashMessage("error", "Adopter account not found.");
    header("Location: dashboard.php");
    exit();
}

$adopter = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $form_type = $_POST['form_type'] ?? "";

    /* ========================= */
    /* PROFILE IMAGE ONLY        */
    /* ========================= */
    if ($form_type == "profile_image") {

        $profile_image = $adopter['profile_image'];

        if (!empty($_FILES['profile_image']['name'])) {

            $allowed_extensions = ["jpg", "jpeg", "png"];
            $file_name = $_FILES['profile_image']['name'];
            $file_tmp = $_FILES['profile_image']['tmp_name'];
            $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

            if (!in_array($file_extension, $allowed_extensions)) {
                $message = "Only JPG and PNG images are allowed.";
                $active_tab = "profile";
            } else {

                if (!is_dir("../images/adopters")) {
                    mkdir("../images/adopters", 0777, true);
                }

                $safe_name = preg_replace("/[^a-zA-Z0-9._-]/", "_", basename($file_name));
                $profile_image = time() . "_" . $safe_name;
                $target = "../images/adopters/" . $profile_image;

                if (move_uploaded_file($file_tmp, $target)) {

                    $update = "UPDATE adopter SET profile_image = ? WHERE adopter_id = ?";
                    $stmt_update = mysqli_prepare($conn, $update);

                    if (!$stmt_update) {
                        die("SQL Prepare Error: " . mysqli_error($conn));
                    }

                    mysqli_stmt_bind_param($stmt_update, "si", $profile_image, $adopter_id);

                    if (mysqli_stmt_execute($stmt_update)) {
                        setFlashMessage("success", "Profile picture updated successfully!");
                        header("Location: profile.php?tab=profile");
                        exit();
                    } else {
                        $message = "Failed to update profile picture.";
                        $active_tab = "profile";
                    }

                } else {
                    $message = "Failed to upload profile image.";
                    $active_tab = "profile";
                }
            }

        } else {
            $message = "Please select an image first.";
            $active_tab = "profile";
        }
    }

    /* ========================= */
    /* PROFILE DETAILS           */
    /* ========================= */
    elseif ($form_type == "profile") {

        $full_name = trim($_POST['full_name']);
        $gender = trim($_POST['gender']);
        $phone = trim($_POST['phone']);

        if ($full_name == "" || $gender == "" || $phone == "") {
            $message = "Please fill in all profile fields.";
            $active_tab = "profile";
        } elseif ($gender != "Male" && $gender != "Female") {
            $message = "Please select a valid gender.";
            $active_tab = "profile";
        } else {

            $update = "UPDATE adopter
                       SET full_name = ?, gender = ?, phone = ?
                       WHERE adopter_id = ?";

            $stmt_update = mysqli_prepare($conn, $update);

            if (!$stmt_update) {
                die("SQL Prepare Error: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt_update,
                "sssi",
                $full_name,
                $gender,
                $phone,
                $adopter_id
            );

            if (mysqli_stmt_execute($stmt_update)) {
                $_SESSION['adopter_name'] = $full_name;
                setFlashMessage("success", "Profile saved successfully!");
                header("Location: profile.php?tab=profile");
                exit();
            } else {
                $message = "Failed to save profile.";
                $active_tab = "profile";
            }
        }
    }

    /* ========================= */
    /* ADDRESS                   */
    /* ========================= */
    elseif ($form_type == "address") {

        $address = trim($_POST['address']);
        $state = trim($_POST['state']);
        $city = trim($_POST['city']);
        $postcode = trim($_POST['postcode']);

        if ($address == "" || $state == "" || $city == "" || $postcode == "") {
            $message = "Please fill in all address fields.";
            $active_tab = "address";
        } else {

            $update = "UPDATE adopter
                       SET address = ?, state = ?, city = ?, postcode = ?
                       WHERE adopter_id = ?";

            $stmt_update = mysqli_prepare($conn, $update);

            if (!$stmt_update) {
                die("SQL Prepare Error: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt_update,
                "ssssi",
                $address,
                $state,
                $city,
                $postcode,
                $adopter_id
            );

            if (mysqli_stmt_execute($stmt_update)) {
                setFlashMessage("success", "Address saved successfully!");
                header("Location: profile.php?tab=address");
                exit();
            } else {
                $message = "Failed to save address.";
                $active_tab = "address";
            }
        }
    }

    /* ========================= */
    /* PREFERENCE                */
    /* ========================= */
    elseif ($form_type == "preference") {

        $preferred_pet_type = trim($_POST['preferred_pet_type']);
        $preferred_pet_age = trim($_POST['preferred_pet_age']);
        $home_environment = trim($_POST['home_environment']);

        if ($preferred_pet_type == "" || $preferred_pet_age == "" || $home_environment == "") {
            $message = "Please fill in all preference fields.";
            $active_tab = "preference";
        } else {

            $update = "UPDATE adopter
                       SET preferred_pet_type = ?, preferred_pet_age = ?, home_environment = ?
                       WHERE adopter_id = ?";

            $stmt_update = mysqli_prepare($conn, $update);

            if (!$stmt_update) {
                die("SQL Prepare Error: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt_update,
                "sssi",
                $preferred_pet_type,
                $preferred_pet_age,
                $home_environment,
                $adopter_id
            );

            if (mysqli_stmt_execute($stmt_update)) {
                setFlashMessage("success", "Adoption preference saved successfully!");
                header("Location: profile.php?tab=preference");
                exit();
            } else {
                $message = "Failed to save adoption preference.";
                $active_tab = "preference";
            }
        }
    }

    /* ========================= */
    /* PASSWORD                  */
    /* ========================= */
    elseif ($form_type == "password") {

        $current_password = trim($_POST['current_password']);
        $new_password = trim($_POST['new_password']);
        $confirm_new_password = trim($_POST['confirm_new_password']);

        if ($current_password == "" || $new_password == "" || $confirm_new_password == "") {
            $message = "Please fill in all password fields.";
            $active_tab = "password";
        } elseif (!password_verify($current_password, $adopter['password'])) {
            $message = "Current password is incorrect.";
            $active_tab = "password";
        } elseif ($new_password != $confirm_new_password) {
            $message = "New password and confirm new password do not match.";
            $active_tab = "password";
        } elseif (strlen($new_password) < 6) {
            $message = "New password must be at least 6 characters.";
            $active_tab = "password";
        } else {

            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $update = "UPDATE adopter SET password = ? WHERE adopter_id = ?";
            $stmt_update = mysqli_prepare($conn, $update);

            if (!$stmt_update) {
                die("SQL Prepare Error: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param($stmt_update, "si", $hashed_password, $adopter_id);

            if (mysqli_stmt_execute($stmt_update)) {
                setFlashMessage("success", "Password changed successfully!");
                header("Location: profile.php?tab=password");
                exit();
            } else {
                $message = "Failed to change password.";
                $active_tab = "password";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Profile | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">

    <style>
        .profile-wrapper {
            display: grid;
            grid-template-columns: 290px 1fr;
            gap: 26px;
            align-items: start;
        }

        .profile-sidebar {
            background: #ffffff;
            border-radius: 26px;
            padding: 28px 22px;
            box-shadow: 0 12px 28px rgba(37, 99, 235, 0.10);
            border: 1px solid #dbeafe;
            text-align: center;
        }

        .profile-image-box {
            position: relative;
            width: 140px;
            height: 140px;
            margin: 0 auto 16px;
        }

        .profile-image-box img,
        .profile-image-placeholder {
            width: 140px;
            height: 140px;
            border-radius: 50%;
            object-fit: cover;
            background: #dbeafe;
            border: 5px solid #dbeafe;
        }

        .profile-image-placeholder {
            display: flex;
            align-items: center;
            justify-content: center;
            color: #1d4ed8;
            font-size: 48px;
            font-weight: 800;
        }

        .profile-edit-btn {
            position: absolute;
            right: 8px;
            bottom: 10px;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #2563eb;
            color: #ffffff;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 18px;
            border: 3px solid #ffffff;
            box-shadow: 0 6px 16px rgba(37, 99, 235, 0.28);
            transition: 0.2s ease;
        }

        .profile-edit-btn:hover {
            background: #1d4ed8;
            transform: scale(1.05);
        }

        .hidden-file {
            display: none;
        }

        .profile-name {
            font-size: 28px;
            font-weight: 800;
            color: #1d4ed8;
            margin-bottom: 4px;
        }

        .profile-email {
            color: #6b7280;
            font-size: 15px;
            margin-bottom: 18px;
        }

        .profile-note {
            background: #eff6ff;
            border-left: 5px solid #2563eb;
            border-radius: 16px;
            padding: 16px;
            text-align: left;
            color: #1d4ed8;
            line-height: 1.6;
            font-size: 14px;
        }

        .profile-main {
            background: #ffffff;
            border-radius: 26px;
            padding: 28px;
            box-shadow: 0 12px 28px rgba(37, 99, 235, 0.10);
            border: 1px solid #dbeafe;
        }

        .profile-tab-bar {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 24px;
            padding-bottom: 18px;
            border-bottom: 1px solid #dbeafe;
        }

        .profile-tab-btn {
            border: none;
            background: #eff6ff;
            color: #1d4ed8;
            padding: 11px 18px;
            border-radius: 999px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.2s ease;
        }

        .profile-tab-btn:hover {
            background: #dbeafe;
        }

        .profile-tab-btn.active {
            background: #2563eb;
            color: white;
            box-shadow: 0 8px 16px rgba(37, 99, 235, 0.22);
        }

        .profile-tab-panel {
            display: none;
        }

        .profile-tab-panel.active {
            display: block;
        }

        .profile-tab-panel h2 {
            margin-top: 0;
            margin-bottom: 6px;
            color: #1d4ed8;
            font-size: 34px;
            font-weight: 800;
        }

        .profile-tab-subtitle {
            margin-bottom: 22px;
            color: #6b7280;
            font-size: 15px;
        }

        .profile-form .form-group {
            margin-bottom: 18px;
        }

        .profile-form label {
            display: block;
            margin-bottom: 8px;
            font-weight: 700;
            color: #374151;
        }

        .profile-form input,
        .profile-form select,
        .profile-form textarea {
            width: 100%;
            padding: 13px 15px;
            border-radius: 14px;
            border: 1px solid #cbd5e1;
            background: #f8fbff;
            font-size: 15px;
            outline: none;
            transition: 0.2s ease;
            box-sizing: border-box;
        }

        .profile-form input:focus,
        .profile-form select:focus,
        .profile-form textarea:focus {
            border-color: #2563eb;
            background: #ffffff;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.10);
        }

        .profile-form textarea {
            min-height: 110px;
            resize: vertical;
        }

        .profile-form .btn {
            margin-top: 8px;
        }

        @media (max-width: 900px) {
            .profile-wrapper {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>My Profile</span>
    </div>

    <div style="display:flex; gap:10px; align-items:center;">
        <a href="dashboard.php" class="header-link">Back to Dashboard</a>
        <a href="../logout.php" class="header-link logout-btn" data-confirm="Are you sure you want to logout from your account?">Logout</a>
    </div>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="page-title">
            <h1>My Profile</h1>
            <p>Manage your profile, address, adoption preference, and password.</p>
        </div>

        <?php
        if ($message != "") {
            echo "<div class='error-box'>" . htmlspecialchars($message) . "</div>";
        }
        ?>

        <div class="profile-wrapper">

            <!-- LEFT SIDE -->
            <div class="profile-sidebar">

                <form method="POST" enctype="multipart/form-data" id="profileImageForm">
                    <input type="hidden" name="form_type" value="profile_image">

                    <div class="profile-image-box">
                        <?php if (!empty($adopter['profile_image'])) { ?>
                            <img src="../images/adopters/<?php echo htmlspecialchars($adopter['profile_image']); ?>" alt="Profile Image" id="profilePreview">
                        <?php } else { ?>
                            <div class="profile-image-placeholder" id="profilePreviewPlaceholder">
                                <?php echo strtoupper(substr($adopter['full_name'], 0, 1)); ?>
                            </div>
                        <?php } ?>

                        <label for="profileImageInput" class="profile-edit-btn" title="Change Profile Picture">✎</label>
                    </div>

                    <input type="file" name="profile_image" id="profileImageInput" class="hidden-file" accept="image/png, image/jpeg, image/jpg">
                </form>

                <div class="profile-name"><?php echo htmlspecialchars($adopter['full_name']); ?></div>
                <div class="profile-email"><?php echo htmlspecialchars($adopter['email']); ?></div>

                <div class="profile-note">
                    Click the pencil icon to change your profile picture.
                </div>
            </div>

            <!-- RIGHT SIDE -->
            <div class="profile-main">

                <div class="profile-tab-bar">
                    <button type="button" class="profile-tab-btn <?php if ($active_tab == 'profile') echo 'active'; ?>" data-tab="profile">Profile</button>
                    <button type="button" class="profile-tab-btn <?php if ($active_tab == 'address') echo 'active'; ?>" data-tab="address">Address</button>
                    <button type="button" class="profile-tab-btn <?php if ($active_tab == 'preference') echo 'active'; ?>" data-tab="preference">Preference</button>
                    <button type="button" class="profile-tab-btn <?php if ($active_tab == 'password') echo 'active'; ?>" data-tab="password">Password</button>
                </div>

                <!-- PROFILE TAB -->
                <div id="profile" class="profile-tab-panel <?php if ($active_tab == 'profile') echo 'active'; ?>">
                    <h2>Profile Details</h2>
                    <div class="profile-tab-subtitle">Update your personal information here.</div>

                    <form method="POST" class="profile-form" data-confirm-submit="Are you sure you want to save your profile details?">
                        <input type="hidden" name="form_type" value="profile">

                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="full_name" value="<?php echo htmlspecialchars($adopter['full_name']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" value="<?php echo htmlspecialchars($adopter['email']); ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label>Gender</label>
                            <select name="gender" required>
                                <option value="">Select gender</option>
                                <option value="Male" <?php if (($adopter['gender'] ?? "") == "Male") echo "selected"; ?>>Male</option>
                                <option value="Female" <?php if (($adopter['gender'] ?? "") == "Female") echo "selected"; ?>>Female</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="text" name="phone" value="<?php echo htmlspecialchars($adopter['phone']); ?>" required>
                        </div>

                        <button type="submit" class="btn">Save Profile</button>
                    </form>
                </div>

                <!-- ADDRESS TAB -->
                <div id="address" class="profile-tab-panel <?php if ($active_tab == 'address') echo 'active'; ?>">
                    <h2>Address</h2>
                    <div class="profile-tab-subtitle">Update your current address information.</div>

                    <form method="POST" class="profile-form" data-confirm-submit="Are you sure you want to save your address?">
                        <input type="hidden" name="form_type" value="address">

                        <div class="form-group">
                            <label>Address</label>
                            <textarea name="address" required><?php echo htmlspecialchars($adopter['address'] ?? ""); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label>State</label>
                            <select name="state" required>
                                <option value="">Select state</option>
                                <?php
                                $states = [
                                    "Johor", "Kedah", "Kelantan", "Melaka", "Negeri Sembilan",
                                    "Pahang", "Perak", "Perlis", "Pulau Pinang", "Sabah",
                                    "Sarawak", "Selangor", "Terengganu", "Kuala Lumpur",
                                    "Labuan", "Putrajaya"
                                ];

                                foreach ($states as $state) {
                                    $selected = (($adopter['state'] ?? "") == $state) ? "selected" : "";
                                    echo "<option value='" . htmlspecialchars($state) . "' $selected>" . htmlspecialchars($state) . "</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>City / District</label>
                            <input type="text" name="city" value="<?php echo htmlspecialchars($adopter['city'] ?? ""); ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Postcode</label>
                            <input type="text" name="postcode" value="<?php echo htmlspecialchars($adopter['postcode'] ?? ""); ?>" required>
                        </div>

                        <button type="submit" class="btn">Save Address</button>
                    </form>
                </div>

                <!-- PREFERENCE TAB -->
                <div id="preference" class="profile-tab-panel <?php if ($active_tab == 'preference') echo 'active'; ?>">
                    <h2>Adoption Preference</h2>
                    <div class="profile-tab-subtitle">Set your pet adoption preferences.</div>

                    <form method="POST" class="profile-form" data-confirm-submit="Are you sure you want to save your adoption preference?">
                        <input type="hidden" name="form_type" value="preference">

                        <div class="form-group">
                            <label>Preferred Pet Type</label>
                            <select name="preferred_pet_type" required>
                                <option value="">Select preferred pet type</option>
                                <option value="Cat" <?php if (($adopter['preferred_pet_type'] ?? "") == "Cat") echo "selected"; ?>>Cat</option>
                                <option value="Dog" <?php if (($adopter['preferred_pet_type'] ?? "") == "Dog") echo "selected"; ?>>Dog</option>
                                <option value="Both" <?php if (($adopter['preferred_pet_type'] ?? "") == "Both") echo "selected"; ?>>Both</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Preferred Pet Age</label>
                            <select name="preferred_pet_age" required>
                                <option value="">Select preferred pet age</option>
                                <option value="Baby" <?php if (($adopter['preferred_pet_age'] ?? "") == "Baby") echo "selected"; ?>>Baby</option>
                                <option value="Young" <?php if (($adopter['preferred_pet_age'] ?? "") == "Young") echo "selected"; ?>>Young</option>
                                <option value="Adult" <?php if (($adopter['preferred_pet_age'] ?? "") == "Adult") echo "selected"; ?>>Adult</option>
                                <option value="Any" <?php if (($adopter['preferred_pet_age'] ?? "") == "Any") echo "selected"; ?>>Any</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Home Environment</label>
                            <select name="home_environment" required>
                                <option value="">Select home environment</option>
                                <option value="Apartment" <?php if (($adopter['home_environment'] ?? "") == "Apartment") echo "selected"; ?>>Apartment</option>
                                <option value="Terrace House" <?php if (($adopter['home_environment'] ?? "") == "Terrace House") echo "selected"; ?>>Terrace House</option>
                                <option value="Semi-D House" <?php if (($adopter['home_environment'] ?? "") == "Semi-D House") echo "selected"; ?>>Semi-D House</option>
                                <option value="Bungalow" <?php if (($adopter['home_environment'] ?? "") == "Bungalow") echo "selected"; ?>>Bungalow</option>
                                <option value="Other" <?php if (($adopter['home_environment'] ?? "") == "Other") echo "selected"; ?>>Other</option>
                            </select>
                        </div>

                        <button type="submit" class="btn">Save Preference</button>
                    </form>
                </div>

                <!-- PASSWORD TAB -->
                <div id="password" class="profile-tab-panel <?php if ($active_tab == 'password') echo 'active'; ?>">
                    <h2>Change Password</h2>
                    <div class="profile-tab-subtitle">Change your account password securely.</div>

                    <form method="POST" class="profile-form" data-confirm-submit="Are you sure you want to change your password?">
                        <input type="hidden" name="form_type" value="password">

                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="password" name="current_password" required>
                        </div>

                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" minlength="6" required>
                        </div>

                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_new_password" minlength="6" required>
                        </div>

                        <button type="submit" class="btn">Change Password</button>
                    </form>
                </div>

            </div>

        </div>
    </div>
</section>

<script>
const tabButtons = document.querySelectorAll(".profile-tab-btn");
const tabPanels = document.querySelectorAll(".profile-tab-panel");

tabButtons.forEach(function(button) {
    button.addEventListener("click", function() {
        const selectedTab = this.getAttribute("data-tab");

        tabButtons.forEach(function(btn) {
            btn.classList.remove("active");
        });

        tabPanels.forEach(function(panel) {
            panel.classList.remove("active");
        });

        this.classList.add("active");
        document.getElementById(selectedTab).classList.add("active");

        history.replaceState(null, "", "profile.php?tab=" + selectedTab);
    });
});

const profileImageInput = document.getElementById("profileImageInput");

if (profileImageInput) {
    profileImageInput.addEventListener("change", function() {
        const file = this.files[0];

        if (file) {
            const reader = new FileReader();

            reader.onload = function(event) {
                let previewImage = document.getElementById("profilePreview");
                let placeholder = document.getElementById("profilePreviewPlaceholder");

                if (previewImage) {
                    previewImage.src = event.target.result;
                } else if (placeholder) {
                    const img = document.createElement("img");
                    img.src = event.target.result;
                    img.alt = "Profile Image";
                    img.id = "profilePreview";
                    placeholder.replaceWith(img);
                }

                setTimeout(function() {
                    document.getElementById("profileImageForm").submit();
                }, 250);
            };

            reader.readAsDataURL(file);
        }
    });
}
</script>

<script src="../js/ui-feedback.js"></script>

</body>
</html>