<?php
include("../includes/session.php");
checkAdopter();
include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];

if (!isset($_GET['id'])) {
    setFlashMessage("error", "Invalid application record.");
    header("Location: history.php");
    exit();
}

$application_id = $_GET['id'];

$sql = "SELECT * FROM adoption_application
        WHERE application_id = ?
        AND adopter_id = ?
        AND status = 'Pending'";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $application_id, $adopter_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    setFlashMessage("error", "This application cannot be cancelled.");
    header("Location: history.php");
    exit();
}

$app = mysqli_fetch_assoc($result);
$pet_id = $app['pet_id'];

$delete = "DELETE FROM adoption_application
           WHERE application_id = ?
           AND adopter_id = ?
           AND status = 'Pending'";

$stmt_delete = mysqli_prepare($conn, $delete);
mysqli_stmt_bind_param($stmt_delete, "ii", $application_id, $adopter_id);

if (mysqli_stmt_execute($stmt_delete)) {

    $update_pet = "UPDATE pet SET status = 'Available' WHERE pet_id = ?";
    $stmt_pet = mysqli_prepare($conn, $update_pet);
    mysqli_stmt_bind_param($stmt_pet, "i", $pet_id);
    mysqli_stmt_execute($stmt_pet);

    setFlashMessage("success", "Application cancelled successfully.");
    header("Location: history.php");
    exit();

} else {
    setFlashMessage("error", "Failed to cancel application.");
    header("Location: history.php");
    exit();
}
?>