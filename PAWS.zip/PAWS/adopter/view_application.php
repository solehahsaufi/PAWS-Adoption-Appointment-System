<?php
include("../includes/session.php");
checkAdopter();
include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];

if (!isset($_GET['id'])) {
    header("Location: history.php");
    exit();
}

$application_id = $_GET['id'];

$sql = "SELECT adoption_application.*, pet.pet_name, pet.species, pet.breed
        FROM adoption_application
        JOIN pet ON adoption_application.pet_id = pet.pet_id
        WHERE adoption_application.application_id = ?
        AND adoption_application.adopter_id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $application_id, $adopter_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    header("Location: history.php");
    exit();
}

$app = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Application | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Application Details</span>
    </div>
    <a href="history.php" class="header-link">Back</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card" style="width:560px;">
            <h2>Application Details</h2>

            <p><strong>Pet Name:</strong> <?php echo htmlspecialchars($app['pet_name']); ?></p>
            <p><strong>Species:</strong> <?php echo htmlspecialchars($app['species']); ?></p>
            <p><strong>Breed:</strong> <?php echo htmlspecialchars($app['breed']); ?></p>
            <p><strong>Application Date:</strong> <?php echo htmlspecialchars($app['application_date']); ?></p>
            <p><strong>Status:</strong> <?php echo htmlspecialchars($app['status']); ?></p>

            <br>

            <p><strong>Reason for Adoption:</strong></p>
            <p style="line-height:1.6;">
                <?php echo nl2br(htmlspecialchars($app['reason'])); ?>
            </p>

            <br>

            <p><strong>Housing Type:</strong> <?php echo htmlspecialchars($app['housing_type'] ?? 'Not provided'); ?></p>
            <p><strong>Pet Care Experience:</strong> <?php echo htmlspecialchars($app['pet_experience'] ?? 'Not provided'); ?></p>
            <p><strong>Current Pets at Home:</strong> <?php echo htmlspecialchars($app['current_pets'] ?? 'Not provided'); ?></p>
            <p><strong>Family Agreement:</strong> <?php echo htmlspecialchars($app['family_agreement'] ?? 'Not provided'); ?></p>
            <p><strong>Veterinary Care Agreement:</strong> <?php echo htmlspecialchars($app['vet_agreement'] ?? 'Not provided'); ?></p>

            <br>

            <?php if ($app['status'] == "Pending") { ?>

                <a href="edit_application.php?id=<?php echo $app['application_id']; ?>" class="btn">
                    Edit Application
                </a>

                <a href="cancel_application.php?id=<?php echo $app['application_id']; ?>"
                   class="btn btn-red"
                   data-confirm="Are you sure you want to cancel this adoption application?">
                   Cancel Application
                </a>

            <?php } else { ?>

                <div class="notice-box">
                    This application has already been reviewed by staff and can no longer be edited.
                </div>

                <?php if ($app['status'] == "Approved") { ?>
                    <div class="notice-box">
                        Your adoption application has been approved. Please wait for PAWS staff to contact you for pet collection arrangement.
                    </div>
                <?php } ?>

            <?php } ?>

        </div>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>