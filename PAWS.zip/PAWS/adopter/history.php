<?php
include("../includes/session.php");
checkAdopter();

include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];

$sql = "SELECT 
            appointment.appointment_id,
            appointment.pet_id,
            appointment.appointment_date,
            TIME_FORMAT(appointment.appointment_time, '%H:%i') AS appointment_time,
            appointment.appointment_reason,
            appointment.appointment_notes,
            appointment.status AS appointment_status,

            pet.pet_name,
            pet.species,
            pet.breed,
            pet.gender,
            pet.age,
            pet.image,
            pet.status AS pet_status,

            adoption_application.application_id,
            adoption_application.application_date,
            adoption_application.status AS application_status

        FROM appointment

        INNER JOIN pet 
        ON appointment.pet_id = pet.pet_id

        LEFT JOIN adoption_application 
        ON appointment.appointment_id = adoption_application.appointment_id
        AND appointment.adopter_id = adoption_application.adopter_id

        WHERE appointment.adopter_id = ?

        ORDER BY appointment.appointment_date DESC, appointment.appointment_time DESC";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $adopter_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Appointment History | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=10">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>My History</span>
    </div>

    <a href="dashboard.php" class="header-link">Back to Dashboard</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="page-title">
            <h1>My Appointments & Applications</h1>
            <p>
                View your adoption appointment history and track your adoption application status.
            </p>
        </div>

        <?php if (mysqli_num_rows($result) == 0) { ?>

            <div class="empty-box">
                <h3>No Appointment Found</h3>
                <p>
                    You have not booked any appointment yet. Please browse available pets and select a pet first.
                </p>
                <a href="pets.php" class="btn">Browse Available Pets</a>
            </div>

        <?php } else { ?>

            <div class="table-card">

                <table>
                    <tr>
                        <th>Pet</th>
                        <th>Appointment Details</th>
                        <th>Appointment Status</th>
                        <th>Application Status</th>
                        <th>Action</th>
                    </tr>

                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>

                        <tr>
                            <td>
                                <div style="display:flex; align-items:center; gap:12px;">

                                    <?php if (!empty($row['image'])) { ?>
                                        <img 
                                            src="../images/pets/<?php echo htmlspecialchars($row['image']); ?>" 
                                            alt="Pet Image"
                                            style="width:70px; height:70px; object-fit:cover; border-radius:14px;"
                                        >
                                    <?php } else { ?>
                                        <div style="width:70px; height:70px; border-radius:14px; background:#dbeafe; display:flex; align-items:center; justify-content:center; color:#1d4ed8; font-weight:bold;">
                                            PAWS
                                        </div>
                                    <?php } ?>

                                    <div>
                                        <strong><?php echo htmlspecialchars($row['pet_name']); ?></strong>
                                        <br>
                                        <small>
                                            <?php echo htmlspecialchars($row['species']); ?> |
                                            <?php echo htmlspecialchars($row['breed']); ?>
                                        </small>
                                        <br>
                                        <small>
                                            Age: <?php echo htmlspecialchars($row['age']); ?> months
                                        </small>
                                    </div>

                                </div>
                            </td>

                            <td>
                                <strong>Date:</strong>
                                <?php echo date("d M Y", strtotime($row['appointment_date'])); ?>
                                <br>

                                <strong>Time:</strong>
                                <?php echo date("h:i A", strtotime($row['appointment_time'])); ?>
                                <br>

                                <strong>Reason:</strong>
                                <?php echo htmlspecialchars($row['appointment_reason']); ?>

                                <?php if (!empty($row['appointment_notes'])) { ?>
                                    <br>
                                    <strong>Notes:</strong>
                                    <?php echo htmlspecialchars($row['appointment_notes']); ?>
                                <?php } ?>
                            </td>

                            <td>
                                <?php if ($row['appointment_status'] == "Scheduled") { ?>

                                    <span class="status status-pending">Scheduled</span>

                                <?php } elseif ($row['appointment_status'] == "Completed") { ?>

                                    <span class="status status-approved">Completed</span>

                                <?php } elseif ($row['appointment_status'] == "Cancelled") { ?>

                                    <span class="status status-rejected">Cancelled</span>

                                <?php } else { ?>

                                    <span class="status">
                                        <?php echo htmlspecialchars($row['appointment_status']); ?>
                                    </span>

                                <?php } ?>
                            </td>

                            <td>
                                <?php if (empty($row['application_id'])) { ?>

                                    <?php if ($row['appointment_status'] == "Completed") { ?>
                                        <span class="status status-pending">Not Submitted</span>
                                    <?php } else { ?>
                                        <span class="status">Not Available</span>
                                    <?php } ?>

                                <?php } else { ?>

                                    <?php if ($row['application_status'] == "Pending") { ?>

                                        <span class="status status-pending">Pending</span>

                                    <?php } elseif ($row['application_status'] == "Approved") { ?>

                                        <span class="status status-approved">Approved</span>

                                    <?php } elseif ($row['application_status'] == "Rejected") { ?>

                                        <span class="status status-rejected">Rejected</span>

                                    <?php } else { ?>

                                        <span class="status">
                                            <?php echo htmlspecialchars($row['application_status']); ?>
                                        </span>

                                    <?php } ?>

                                <?php } ?>
                            </td>

                            <td>
                                <?php if ($row['appointment_status'] == "Scheduled") { ?>

                                    <a 
                                        href="edit_appointment.php?id=<?php echo $row['appointment_id']; ?>" 
                                        class="btn"
                                    >
                                        Edit Appointment
                                    </a>

                                    <br><br>

                                    <a 
                                        href="cancel_appointment.php?id=<?php echo $row['appointment_id']; ?>"
                                        class="btn btn-red"
                                        data-confirm="Are you sure you want to cancel this appointment? The pet will become available again."
                                    >
                                        Cancel Appointment
                                    </a>

                                <?php } elseif ($row['appointment_status'] == "Completed" && empty($row['application_id'])) { ?>

                                    <a 
                                        href="application.php?appointment_id=<?php echo $row['appointment_id']; ?>" 
                                        class="btn"
                                    >
                                        Submit Application
                                    </a>

                                <?php } elseif (!empty($row['application_id'])) { ?>

                                    <a 
                                        href="view_application.php?id=<?php echo $row['application_id']; ?>" 
                                        class="btn"
                                    >
                                        View Application
                                    </a>

                                <?php } elseif ($row['appointment_status'] == "Cancelled") { ?>

                                    <span style="color:#6b7280; font-size:14px;">
                                        No action available
                                    </span>

                                <?php } else { ?>

                                    <span style="color:#6b7280; font-size:14px;">
                                        No action available
                                    </span>

                                <?php } ?>
                            </td>
                        </tr>

                    <?php } ?>

                </table>

            </div>

        <?php } ?>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>