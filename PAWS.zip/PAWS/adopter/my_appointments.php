<?php
include("../includes/session.php");
checkAdopter();

include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];

$sql = "SELECT 
            appointment.*,
            TIME_FORMAT(appointment.appointment_time, '%H:%i') AS formatted_time,
            pet.pet_name,
            pet.species,
            pet.breed,
            pet.image,
            adoption_application.application_id,
            adoption_application.status AS application_status
        FROM appointment
        INNER JOIN pet 
        ON appointment.pet_id = pet.pet_id
        LEFT JOIN adoption_application 
        ON appointment.appointment_id = adoption_application.appointment_id
        AND appointment.adopter_id = adoption_application.adopter_id
        WHERE appointment.adopter_id = ?
        ORDER BY appointment.appointment_date DESC, appointment.appointment_time DESC";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $adopter_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

function showAppointmentStatus($status)
{
    if ($status == "Pending") {
        return "<span class='status status-pending'>Pending Approval</span>";
    } elseif ($status == "Approved") {
        return "<span class='status status-approved'>Approved</span>";
    } elseif ($status == "Rejected") {
        return "<span class='status status-rejected'>Rejected</span>";
    } elseif ($status == "Cancelled") {
        return "<span class='status status-rejected'>Cancelled</span>";
    } elseif ($status == "Completed") {
        return "<span class='status status-approved'>Completed</span>";
    } else {
        return "<span class='status'>" . htmlspecialchars($status) . "</span>";
    }
}

function showApplicationStatus($status)
{
    if ($status == "Pending") {
        return "<span class='status status-pending'>Application Pending</span>";
    } elseif ($status == "Approved") {
        return "<span class='status status-approved'>Application Approved</span>";
    } elseif ($status == "Rejected") {
        return "<span class='status status-rejected'>Application Rejected</span>";
    } else {
        return "<span class='status'>" . htmlspecialchars($status) . "</span>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Appointments | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>My Appointments</span>
    </div>

    <a href="dashboard.php" class="header-link">Back to Dashboard</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="page-title">
            <h1>My Appointments</h1>
            <p>
                View your appointment requests, check staff approval status, and submit an adoption application after approval.
            </p>
        </div>

        <?php if (mysqli_num_rows($result) == 0) { ?>

            <div class="empty-box">
                <h3>No Appointment Found</h3>
                <p>
                    You have not requested any appointment yet. Please browse available pets and select a pet before booking an appointment.
                </p>
                <a href="pets.php" class="btn">Browse Available Pets</a>
            </div>

        <?php } else { ?>

            <div class="table-card">

                <table>
                    <tr>
                        <th>Pet</th>
                        <th>Date & Time</th>
                        <th>Reason</th>
                        <th>Booking Status</th>
                        <th>Application</th>
                        <th>Action</th>
                    </tr>

                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>

                        <tr>
                            <td>
                                <div style="display:flex; align-items:center; gap:12px;">

                                    <?php if (!empty($row['image'])) { ?>
                                        <img 
                                            src="../images/pets/<?php echo htmlspecialchars($row['image']); ?>" 
                                            alt="Pet Image"
                                            style="width:68px; height:68px; object-fit:cover; border-radius:14px;"
                                        >
                                    <?php } else { ?>
                                        <div style="width:68px; height:68px; border-radius:14px; background:#dbeafe; display:flex; align-items:center; justify-content:center; color:#1d4ed8; font-weight:bold;">
                                            PAWS
                                        </div>
                                    <?php } ?>

                                    <div>
                                        <strong><?php echo htmlspecialchars($row['pet_name']); ?></strong>
                                        <br>
                                        <small>
                                            <?php echo htmlspecialchars($row['species']); ?> |
                                            <?php echo htmlspecialchars($row['breed']); ?>
                                        </small>
                                    </div>

                                </div>
                            </td>

                            <td>
                                <strong>Date:</strong>
                                <?php echo date("d M Y", strtotime($row['appointment_date'])); ?>
                                <br>

                                <strong>Time:</strong>
                                <?php echo date("h:i A", strtotime($row['formatted_time'])); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row['appointment_reason']); ?>

                                <?php if (!empty($row['appointment_notes'])) { ?>
                                    <br>
                                    <small>
                                        <strong>Notes:</strong>
                                        <?php echo htmlspecialchars($row['appointment_notes']); ?>
                                    </small>
                                <?php } ?>
                            </td>

                            <td>
                                <?php echo showAppointmentStatus($row['status']); ?>

                                <?php if ($row['status'] == "Pending") { ?>
                                    <br><br>
                                    <small style="color:#6b7280;">
                                        Waiting for staff approval.
                                    </small>

                                <?php } elseif ($row['status'] == "Approved") { ?>
                                    <br><br>
                                    <small style="color:#6b7280;">
                                        Booking approved. You may submit an adoption application.
                                    </small>

                                <?php } elseif ($row['status'] == "Rejected") { ?>
                                    <br><br>
                                    <small style="color:#6b7280;">
                                        Booking request was rejected by staff.
                                    </small>

                                <?php } elseif ($row['status'] == "Cancelled") { ?>
                                    <br><br>
                                    <small style="color:#6b7280;">
                                        Appointment was cancelled.
                                    </small>
                                <?php } ?>
                            </td>

                            <td>
                                <?php if (empty($row['application_id'])) { ?>

                                    <?php if ($row['status'] == "Approved") { ?>
                                        <span class="status status-pending">Not Submitted</span>
                                    <?php } else { ?>
                                        <span style="color:#6b7280; font-size:14px;">
                                            Not available yet
                                        </span>
                                    <?php } ?>

                                <?php } else { ?>

                                    <?php echo showApplicationStatus($row['application_status']); ?>

                                <?php } ?>
                            </td>

                            <td>
                                <?php if ($row['status'] == "Pending") { ?>

                                    <a 
                                        href="edit_appointment.php?id=<?php echo $row['appointment_id']; ?>" 
                                        class="btn"
                                    >
                                        Edit
                                    </a>

                                    <br><br>

                                    <a 
                                        href="cancel_appointment.php?id=<?php echo $row['appointment_id']; ?>"
                                        class="btn btn-red"
                                        data-confirm="Are you sure you want to cancel this appointment request? The pet will become available again."
                                    >
                                        Cancel
                                    </a>

                                <?php } elseif ($row['status'] == "Approved" && empty($row['application_id'])) { ?>

                                    <a 
                                        href="application.php?appointment_id=<?php echo $row['appointment_id']; ?>" 
                                        class="btn"
                                    >
                                        Submit Application
                                    </a>

                                <?php } elseif ($row['status'] == "Approved" && !empty($row['application_id'])) { ?>

                                    <a 
                                        href="view_application.php?id=<?php echo $row['application_id']; ?>" 
                                        class="btn"
                                    >
                                        View Application
                                    </a>

                                <?php } elseif ($row['status'] == "Rejected") { ?>

                                    <a href="pets.php" class="btn">
                                        Browse Other Pets
                                    </a>

                                <?php } else { ?>

                                    <span style="color:#6b7280; font-size:14px;">
                                        No action
                                    </span>

                                <?php } ?>
                            </td>
                        </tr>

                    <?php } ?>

                </table>

            </div>

        <?php } ?>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>