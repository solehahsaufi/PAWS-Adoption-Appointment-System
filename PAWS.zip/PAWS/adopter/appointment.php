<?php
include("../includes/session.php");
checkAdopter();

include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];
$message = "";

$all_slots = [
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "13:00",
    "14:00",
    "15:00"
];

if (!isset($_GET['pet_id'])) {
    setFlashMessage("warning", "Please select a pet first before booking an appointment.");
    header("Location: pets.php?mode=book");
    exit();
}

$pet_id = intval($_GET['pet_id']);

$sql_pet = "SELECT * FROM pet WHERE pet_id = ?";
$stmt_pet = mysqli_prepare($conn, $sql_pet);

if (!$stmt_pet) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_pet, "i", $pet_id);
mysqli_stmt_execute($stmt_pet);

$pet_result = mysqli_stmt_get_result($stmt_pet);

if (mysqli_num_rows($pet_result) != 1) {
    setFlashMessage("error", "Pet record not found.");
    header("Location: pets.php?mode=book");
    exit();
}

$pet = mysqli_fetch_assoc($pet_result);

if ($pet['status'] != "Available") {
    setFlashMessage("warning", "This pet is no longer available for appointment booking.");
    header("Location: pets.php?mode=book");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $appointment_date = trim($_POST['appointment_date']);
    $appointment_time = trim($_POST['appointment_time']);
    $appointment_reason = trim($_POST['appointment_reason']);
    $appointment_notes = trim($_POST['appointment_notes']);

    if ($appointment_date == "" || $appointment_time == "" || $appointment_reason == "") {
        $message = "Please fill in appointment date, time, and reason.";
    } elseif (strtotime($appointment_date) < strtotime(date("Y-m-d"))) {
        $message = "Past dates are not allowed.";
    } elseif (date("w", strtotime($appointment_date)) == 3) {
        $message = "PAWS is closed every Wednesday. Please select another date.";
    } elseif (!in_array($appointment_time, $all_slots)) {
        $message = "Invalid appointment time selected.";
    } elseif ($appointment_date == date("Y-m-d") && strtotime($appointment_time) <= strtotime(date("H:i"))) {
        $message = "Past time slots are not allowed for today.";
    } else {

        mysqli_begin_transaction($conn);

        $check_pet = "SELECT status FROM pet WHERE pet_id = ? FOR UPDATE";
        $stmt_check_pet = mysqli_prepare($conn, $check_pet);
        mysqli_stmt_bind_param($stmt_check_pet, "i", $pet_id);
        mysqli_stmt_execute($stmt_check_pet);
        $pet_status_result = mysqli_stmt_get_result($stmt_check_pet);
        $latest_pet = mysqli_fetch_assoc($pet_status_result);

        if ($latest_pet['status'] != "Available") {

            mysqli_rollback($conn);
            $message = "This pet is no longer available for appointment booking.";

        } else {

            $check_slot = "SELECT * FROM appointment
                           WHERE appointment_date = ?
                           AND TIME_FORMAT(appointment_time, '%H:%i') = ?
                           AND status != 'Cancelled'";

            $stmt_check = mysqli_prepare($conn, $check_slot);

            if (!$stmt_check) {
                mysqli_rollback($conn);
                die("SQL Prepare Error: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param($stmt_check, "ss", $appointment_date, $appointment_time);
            mysqli_stmt_execute($stmt_check);
            $slot_result = mysqli_stmt_get_result($stmt_check);

            if (mysqli_num_rows($slot_result) > 0) {

                mysqli_rollback($conn);
                $message = "This appointment slot has already been booked. Please select another slot.";

            } else {

                $insert = "INSERT INTO appointment
                           (adopter_id, pet_id, appointment_date, appointment_time, appointment_reason, appointment_notes, status)
                           VALUES (?, ?, ?, ?, ?, ?, 'Pending')";

                $stmt_insert = mysqli_prepare($conn, $insert);

                if (!$stmt_insert) {
                    mysqli_rollback($conn);
                    die("SQL Prepare Error: " . mysqli_error($conn));
                }

                mysqli_stmt_bind_param(
                    $stmt_insert,
                    "iissss",
                    $adopter_id,
                    $pet_id,
                    $appointment_date,
                    $appointment_time,
                    $appointment_reason,
                    $appointment_notes
                );

                $ok1 = mysqli_stmt_execute($stmt_insert);

                $update_pet = "UPDATE pet SET status = 'Booked' WHERE pet_id = ?";
                $stmt_update_pet = mysqli_prepare($conn, $update_pet);
                mysqli_stmt_bind_param($stmt_update_pet, "i", $pet_id);
                $ok2 = mysqli_stmt_execute($stmt_update_pet);

                if ($ok1 && $ok2) {
                    mysqli_commit($conn);
                    setFlashMessage("success", "Appointment request submitted successfully! Please wait for staff approval.");
                    header("Location: my_appointments.php");
                    exit();
                } else {
                    mysqli_rollback($conn);
                    $message = "Failed to book appointment. Please try again.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Appointment | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=10">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Book Appointment</span>
    </div>

    <a href="pets.php?mode=book" class="header-link">Back to Pets</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card">
            <h2>Book Adoption Appointment</h2>

            <div class="notice-box">
                Please select an available date and time to meet the selected pet.
                PAWS is closed every Wednesday.
            </div>

            <?php
            if ($message != "") {
                echo "<div class='error-box'>$message</div>";
            }
            ?>

            <div class="notice-box">
                <strong>Selected Pet:</strong>
                <?php echo htmlspecialchars($pet['pet_name']); ?>
                <br>

                <strong>Species:</strong>
                <?php echo htmlspecialchars($pet['species']); ?>
                <br>

                <strong>Breed:</strong>
                <?php echo htmlspecialchars($pet['breed']); ?>
                <br>

                <strong>Status:</strong>
                <span class="status status-approved">Available</span>
            </div>

            <form method="POST" data-confirm-submit="Are you sure you want to book this appointment slot?">

                <label>Appointment Date</label>
                <input 
                    type="date" 
                    name="appointment_date" 
                    id="appointment_date"
                    min="<?php echo date('Y-m-d'); ?>"
                    required
                >

                <label>Available Time Slot</label>
                <select name="appointment_time" id="appointment_time" required>
                    <option value="">Select date first</option>
                </select>
                <small id="slotMessage" class="field-error"></small>

                <label>Reason for Appointment</label>
                <select name="appointment_reason" required>
                    <option value="">Select reason</option>
                    <option value="Meet the pet before adoption">Meet the pet before adoption</option>
                    <option value="Ask about pet care">Ask about pet care</option>
                    <option value="Discuss adoption process">Discuss adoption process</option>
                    <option value="Other">Other</option>
                </select>

                <label>Additional Notes</label>
                <textarea 
                    name="appointment_notes"
                    placeholder="Write any notes for PAWS staff"></textarea>

                <button type="submit" class="btn">Book Appointment</button>

            </form>

        </div>

    </div>
</section>

<script>
const appointmentDate = document.getElementById("appointment_date");
const appointmentTime = document.getElementById("appointment_time");
const slotMessage = document.getElementById("slotMessage");

function loadAvailableSlots() {
    const selectedDate = appointmentDate.value;

    appointmentTime.innerHTML = "<option value=''>Loading slots...</option>";
    slotMessage.textContent = "";

    if (selectedDate === "") {
        appointmentTime.innerHTML = "<option value=''>Select date first</option>";
        return;
    }

    fetch("get_available_slots.php?date=" + selectedDate)
        .then(response => response.json())
        .then(data => {

            appointmentTime.innerHTML = "";

            if (data.status === "success") {

                appointmentTime.innerHTML = "<option value=''>Select available time</option>";

                data.slots.forEach(function(slot) {
                    const option = document.createElement("option");
                    option.value = slot;
                    option.textContent = slot;
                    appointmentTime.appendChild(option);
                });

            } else {
                appointmentTime.innerHTML = "<option value=''>" + data.message + "</option>";
                slotMessage.textContent = data.message;
            }
        })
        .catch(error => {
            appointmentTime.innerHTML = "<option value=''>Error loading slots</option>";
            slotMessage.textContent = "Unable to load appointment slots.";
        });
}

appointmentDate.addEventListener("change", loadAvailableSlots);
</script>

<script src="../js/ui-feedback.js"></script>

</body>
</html>