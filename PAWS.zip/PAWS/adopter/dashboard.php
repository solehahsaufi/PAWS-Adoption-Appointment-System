<?php
include("../includes/session.php");
checkAdopter();

include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];
$adopter_name = $_SESSION['adopter_name'] ?? "Adopter";

$sql = "SELECT full_name, profile_image FROM adopter WHERE adopter_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $adopter_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$adopter = mysqli_fetch_assoc($result);

$profile_image = $adopter['profile_image'] ?? "";
$full_name = $adopter['full_name'] ?? $adopter_name;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Adopter Dashboard | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>PAWS Adoption System</span>
    </div>

    <a href="profile.php" class="profile-header-btn" title="My Profile">
        <?php if (!empty($profile_image)) { ?>
            <img src="../images/adopters/<?php echo htmlspecialchars($profile_image); ?>" alt="Profile">
        <?php } else { ?>
            <span><?php echo strtoupper(substr($full_name, 0, 1)); ?></span>
        <?php } ?>
    </a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="dashboard-hero">
            <div class="dashboard-hero-content">
                <span class="dashboard-hero-badge">
                    Welcome, <?php echo htmlspecialchars($full_name); ?>
                </span>

                <h1>Helping Pets Find Their Loving Homes</h1>

                <p>
                    PAWS Animal Welfare Society is dedicated to protecting, caring for, 
                    and rehoming rescued cats and dogs. Through this system, adopters 
                    can browse available pets, book adoption appointments after selecting a pet, 
                    submit applications, and track the adoption process more easily.
                </p>

                <a href="pets.php" class="btn">Browse Available Pets</a>
            </div>
        </div>

        <div class="page-title">
            <h1>Adopter Dashboard</h1>
            <p>Select a service below to continue your adoption process.</p>
        </div>

        <div class="dashboard-action-grid">

            <div class="dashboard-action-card">
                <h3>Browse Pets</h3>
                <p>
                    View cats and dogs that are currently available for adoption. 
                    Select a pet first before booking an appointment.
                </p>
                <a href="pets.php" class="btn">Browse Pets</a>
            </div>

            <div class="dashboard-action-card">
                <h3>My Appointments</h3>
                <p>
                    View, edit, or cancel your scheduled adoption appointments.
                </p>
                <a href="my_appointments.php" class="btn">View Appointments</a>
            </div>

            <div class="dashboard-action-card">
                <h3>Application Status</h3>
                <p>
                    Track your submitted adoption applications and review the result.
                </p>
                <a href="application_status.php" class="btn">View Status</a>
            </div>

        </div>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>