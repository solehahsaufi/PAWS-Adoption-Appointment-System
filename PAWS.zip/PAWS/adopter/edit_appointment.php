<?php
include("../includes/session.php");
checkAdopter();

include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];
$message = "";

$all_slots = [
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "13:00",
    "14:00",
    "15:00"
];

if (!isset($_GET['id'])) {
    setFlashMessage("error", "Invalid appointment record.");
    header("Location: my_appointments.php");
    exit();
}

$appointment_id = intval($_GET['id']);

$sql = "SELECT appointment.*, pet.pet_name, pet.species, pet.breed, pet.image
        FROM appointment
        INNER JOIN pet ON appointment.pet_id = pet.pet_id
        WHERE appointment.appointment_id = ?
        AND appointment.adopter_id = ?
        AND appointment.status IN ('Pending','Approved')";

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "ii", $appointment_id, $adopter_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    setFlashMessage("error", "Only pending or approved appointments can be edited.");
    header("Location: my_appointments.php");
    exit();
}

$appointment = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $appointment_date = trim($_POST['appointment_date']);
    $appointment_time = trim($_POST['appointment_time']);
    $appointment_reason = trim($_POST['appointment_reason']);
    $appointment_notes = trim($_POST['appointment_notes']);

    if ($appointment_date == "" || $appointment_time == "" || $appointment_reason == "") {
        $message = "Please fill in appointment date, time, and reason.";
    } elseif (strtotime($appointment_date) < strtotime(date("Y-m-d"))) {
        $message = "Past dates are not allowed.";
    } elseif (date("w", strtotime($appointment_date)) == 3) {
        $message = "PAWS is closed every Wednesday. Please select another date.";
    } elseif (!in_array($appointment_time, $all_slots)) {
        $message = "Invalid appointment time selected.";
    } elseif ($appointment_date == date("Y-m-d") && strtotime($appointment_time) <= strtotime(date("H:i"))) {
        $message = "Past time slots are not allowed for today.";
    } else {

        /*
            Check whether the selected slot is already used by another active appointment.
            Rejected and Cancelled appointments do not block the slot.
            This appointment itself is excluded so adopter can keep the same time.
        */
        $check_slot = "SELECT * FROM appointment
                       WHERE appointment_date = ?
                       AND TIME_FORMAT(appointment_time, '%H:%i') = ?
                       AND status IN ('Pending','Approved','Completed')
                       AND appointment_id != ?";

        $stmt_check = mysqli_prepare($conn, $check_slot);

        if (!$stmt_check) {
            die("SQL Prepare Error: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt_check, "ssi", $appointment_date, $appointment_time, $appointment_id);
        mysqli_stmt_execute($stmt_check);

        $slot_result = mysqli_stmt_get_result($stmt_check);

        if (mysqli_num_rows($slot_result) > 0) {
            $message = "This appointment slot has already been booked. Please select another slot.";
        } else {

            /*
                When adopter edits an approved appointment, status becomes Pending again.
                This is more logical because staff must review the new date/time.
            */
            $update = "UPDATE appointment
                       SET appointment_date = ?,
                           appointment_time = ?,
                           appointment_reason = ?,
                           appointment_notes = ?,
                           status = 'Pending'
                       WHERE appointment_id = ?
                       AND adopter_id = ?
                       AND status IN ('Pending','Approved')";

            $stmt_update = mysqli_prepare($conn, $update);

            if (!$stmt_update) {
                die("SQL Prepare Error: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt_update,
                "ssssii",
                $appointment_date,
                $appointment_time,
                $appointment_reason,
                $appointment_notes,
                $appointment_id,
                $adopter_id
            );

            if (mysqli_stmt_execute($stmt_update)) {
                setFlashMessage("success", "Appointment updated successfully! Please wait for staff approval again.");
                header("Location: my_appointments.php");
                exit();
            } else {
                die("SQL Execute Error: " . mysqli_stmt_error($stmt_update));
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Appointment | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Edit Appointment</span>
    </div>

    <a href="my_appointments.php" class="header-link">Back to My Appointments</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card">
            <h2>Edit Appointment</h2>

            <div class="notice-box">
                You can edit a pending or approved appointment. After editing, the appointment status will return to 
                <strong>Pending</strong> because staff must review the new booking details.
            </div>

            <?php
            if ($message != "") {
                echo "<div class='error-box'>$message</div>";
            }
            ?>

            <div class="notice-box">
                <strong>Selected Pet:</strong>
                <?php echo htmlspecialchars($appointment['pet_name']); ?>
                <br>

                <strong>Species:</strong>
                <?php echo htmlspecialchars($appointment['species']); ?>
                <br>

                <strong>Breed:</strong>
                <?php echo htmlspecialchars($appointment['breed']); ?>
                <br>

                <strong>Current Status:</strong>
                <?php if ($appointment['status'] == "Pending") { ?>
                    <span class="status status-pending">Pending Approval</span>
                <?php } elseif ($appointment['status'] == "Approved") { ?>
                    <span class="status status-approved">Approved</span>
                <?php } ?>
            </div>

            <form method="POST" data-confirm-submit="Are you sure you want to update this appointment? Staff will need to approve it again.">

                <label>Appointment Date</label>
                <input 
                    type="date" 
                    name="appointment_date" 
                    id="appointment_date"
                    min="<?php echo date('Y-m-d'); ?>"
                    value="<?php echo htmlspecialchars($appointment['appointment_date']); ?>"
                    required
                >

                <label>Available Time Slot</label>
                <select name="appointment_time" id="appointment_time" required>
                    <option value="">Select date first</option>
                </select>
                <small id="slotMessage" class="field-error"></small>

                <label>Reason for Appointment</label>
                <select name="appointment_reason" required>
                    <option value="">Select reason</option>

                    <option value="Meet the pet before adoption" <?php if ($appointment['appointment_reason'] == "Meet the pet before adoption") echo "selected"; ?>>
                        Meet the pet before adoption
                    </option>

                    <option value="Ask about pet care" <?php if ($appointment['appointment_reason'] == "Ask about pet care") echo "selected"; ?>>
                        Ask about pet care
                    </option>

                    <option value="Discuss adoption process" <?php if ($appointment['appointment_reason'] == "Discuss adoption process") echo "selected"; ?>>
                        Discuss adoption process
                    </option>

                    <option value="Other" <?php if ($appointment['appointment_reason'] == "Other") echo "selected"; ?>>
                        Other
                    </option>
                </select>

                <label>Additional Notes</label>
                <textarea 
                    name="appointment_notes"
                    placeholder="Write any notes for PAWS staff"><?php echo htmlspecialchars($appointment['appointment_notes'] ?? ""); ?></textarea>

                <button type="submit" class="btn">Update Appointment</button>

            </form>

        </div>

    </div>
</section>

<script>
const appointmentDate = document.getElementById("appointment_date");
const appointmentTime = document.getElementById("appointment_time");
const slotMessage = document.getElementById("slotMessage");

const currentSelectedTime = "<?php echo date('H:i', strtotime($appointment['appointment_time'])); ?>";
const appointmentId = "<?php echo $appointment_id; ?>";

function loadAvailableSlots(selectedTime = "") {
    const selectedDate = appointmentDate.value;

    appointmentTime.innerHTML = "<option value=''>Loading slots...</option>";
    slotMessage.textContent = "";

    if (selectedDate === "") {
        appointmentTime.innerHTML = "<option value=''>Select date first</option>";
        return;
    }

    fetch("get_available_slots.php?date=" + selectedDate + "&appointment_id=" + appointmentId)
        .then(response => response.json())
        .then(data => {

            appointmentTime.innerHTML = "";

            if (data.status === "success") {

                appointmentTime.innerHTML = "<option value=''>Select available time</option>";

                data.slots.forEach(function(slot) {
                    const option = document.createElement("option");
                    option.value = slot;
                    option.textContent = slot;

                    if (slot === selectedTime) {
                        option.selected = true;
                    }

                    appointmentTime.appendChild(option);
                });

            } else {
                appointmentTime.innerHTML = "<option value=''>" + data.message + "</option>";
                slotMessage.textContent = data.message;
            }
        })
        .catch(error => {
            appointmentTime.innerHTML = "<option value=''>Error loading slots</option>";
            slotMessage.textContent = "Unable to load appointment slots.";
        });
}

appointmentDate.addEventListener("change", function () {
    loadAvailableSlots();
});

loadAvailableSlots(currentSelectedTime);
</script>

<script src="../js/ui-feedback.js"></script>

</body>
</html>