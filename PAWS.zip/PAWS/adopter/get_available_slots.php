<?php
include("../connection.php");

header("Content-Type: application/json");

$all_slots = [
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "13:00",
    "14:00",
    "15:00"
];

if (!isset($_GET['date'])) {
    echo json_encode([
        "status" => "error",
        "message" => "No date selected."
    ]);
    exit();
}

$selected_date = $_GET['date'];
$appointment_id = isset($_GET['appointment_id']) ? intval($_GET['appointment_id']) : 0;

if ($selected_date == "") {
    echo json_encode([
        "status" => "error",
        "message" => "Please select a date."
    ]);
    exit();
}

if (strtotime($selected_date) < strtotime(date("Y-m-d"))) {
    echo json_encode([
        "status" => "error",
        "message" => "Past dates are not allowed."
    ]);
    exit();
}

$day_number = date("w", strtotime($selected_date));

if ($day_number == 3) {
    echo json_encode([
        "status" => "closed",
        "message" => "PAWS is closed every Wednesday."
    ]);
    exit();
}

$sql = "SELECT TIME_FORMAT(appointment_time, '%H:%i') AS booked_time
        FROM appointment
        WHERE appointment_date = ?
        AND status != 'Cancelled'";

if ($appointment_id > 0) {
    $sql .= " AND appointment_id != ?";
}

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    echo json_encode([
        "status" => "error",
        "message" => "SQL error."
    ]);
    exit();
}

if ($appointment_id > 0) {
    mysqli_stmt_bind_param($stmt, "si", $selected_date, $appointment_id);
} else {
    mysqli_stmt_bind_param($stmt, "s", $selected_date);
}

mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$booked_slots = [];

while ($row = mysqli_fetch_assoc($result)) {
    $booked_slots[] = $row['booked_time'];
}

$available_slots = [];

foreach ($all_slots as $slot) {

    if ($selected_date == date("Y-m-d") && strtotime($slot) <= strtotime(date("H:i"))) {
        continue;
    }

    if (!in_array($slot, $booked_slots)) {
        $available_slots[] = $slot;
    }
}

if (count($available_slots) > 0) {
    echo json_encode([
        "status" => "success",
        "slots" => $available_slots,
        "message" => "Available slots found."
    ]);
} else {
    echo json_encode([
        "status" => "full",
        "message" => "All appointment slots are fully booked for this date."
    ]);
}

exit();
?>