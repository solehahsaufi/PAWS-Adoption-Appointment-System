<?php
include("../includes/session.php");
checkAdopter();
include("../connection.php");
include("../includes/flash.php");

$adopter_id = $_SESSION['adopter_id'];
$message = "";

if (!isset($_GET['id'])) {
    header("Location: history.php");
    exit();
}

$application_id = $_GET['id'];

$sql = "SELECT adoption_application.*, pet.pet_name, pet.species, pet.breed
        FROM adoption_application
        JOIN pet ON adoption_application.pet_id = pet.pet_id
        WHERE adoption_application.application_id = ?
        AND adoption_application.adopter_id = ?
        AND adoption_application.status = 'Pending'";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $application_id, $adopter_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    setFlashMessage("error", "This application cannot be edited.");
    header("Location: history.php");
    exit();
}

$app = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $reason = trim($_POST['reason']);
    $housing_type = trim($_POST['housing_type']);
    $pet_experience = trim($_POST['pet_experience']);
    $current_pets = trim($_POST['current_pets']);
    $family_agreement = trim($_POST['family_agreement']);
    $vet_agreement = trim($_POST['vet_agreement']);

    if (
        $reason == "" ||
        $housing_type == "" ||
        $pet_experience == "" ||
        $current_pets == "" ||
        $family_agreement == "" ||
        $vet_agreement == ""
    ) {
        $message = "Please fill in all required fields.";
    } else {

        $update = "UPDATE adoption_application
                   SET reason = ?,
                       housing_type = ?,
                       pet_experience = ?,
                       current_pets = ?,
                       family_agreement = ?,
                       vet_agreement = ?
                   WHERE application_id = ?
                   AND adopter_id = ?
                   AND status = 'Pending'";

        $stmt_update = mysqli_prepare($conn, $update);

        if (!$stmt_update) {
            die("SQL Prepare Error: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param(
            $stmt_update,
            "ssssssii",
            $reason,
            $housing_type,
            $pet_experience,
            $current_pets,
            $family_agreement,
            $vet_agreement,
            $application_id,
            $adopter_id
        );

        if (mysqli_stmt_execute($stmt_update)) {
            setFlashMessage("success", "Application updated successfully!");
            header("Location: view_application.php?id=$application_id");
            exit();
        } else {
            die("SQL Execute Error: " . mysqli_stmt_error($stmt_update));
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Application | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Edit Application</span>
    </div>
    <a href="view_application.php?id=<?php echo $application_id; ?>" class="header-link">Back</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card" style="width:560px;">
            <h2>Edit Adoption Application</h2>

            <?php
            if ($message != "") {
                echo "<div class='error-box'>$message</div>";
            }
            ?>

            <p style="text-align:center; margin-bottom:20px; line-height:1.6;">
                Pet selected:
                <br>
                <strong style="color:#1d4ed8;">
                    <?php echo htmlspecialchars($app['pet_name']); ?>
                </strong>
                <br>
                <?php echo htmlspecialchars($app['species']); ?> -
                <?php echo htmlspecialchars($app['breed']); ?>
            </p>

            <form method="POST" data-confirm-submit="Are you sure you want to save changes for this application?">

                <label>Why do you want to adopt this pet?</label>
                <textarea name="reason" required><?php echo htmlspecialchars($app['reason']); ?></textarea>

                <label>Housing Type</label>
                <select name="housing_type" required>
                    <option value="">Select housing type</option>
                    <option value="Landed House" <?php if (($app['housing_type'] ?? '') == "Landed House") echo "selected"; ?>>Landed House</option>
                    <option value="Apartment" <?php if (($app['housing_type'] ?? '') == "Apartment") echo "selected"; ?>>Apartment</option>
                    <option value="Condominium" <?php if (($app['housing_type'] ?? '') == "Condominium") echo "selected"; ?>>Condominium</option>
                    <option value="Rental House" <?php if (($app['housing_type'] ?? '') == "Rental House") echo "selected"; ?>>Rental House</option>
                </select>

                <label>Do you have experience caring for pets?</label>
                <select name="pet_experience" required>
                    <option value="">Select experience</option>
                    <option value="No Experience" <?php if (($app['pet_experience'] ?? '') == "No Experience") echo "selected"; ?>>No Experience</option>
                    <option value="Beginner" <?php if (($app['pet_experience'] ?? '') == "Beginner") echo "selected"; ?>>Beginner</option>
                    <option value="Experienced" <?php if (($app['pet_experience'] ?? '') == "Experienced") echo "selected"; ?>>Experienced</option>
                </select>

                <label>Do you currently have pets at home?</label>
                <select name="current_pets" required>
                    <option value="">Select answer</option>
                    <option value="None" <?php if (($app['current_pets'] ?? '') == "None") echo "selected"; ?>>None</option>
                    <option value="Cat" <?php if (($app['current_pets'] ?? '') == "Cat") echo "selected"; ?>>Cat</option>
                    <option value="Dog" <?php if (($app['current_pets'] ?? '') == "Dog") echo "selected"; ?>>Dog</option>
                    <option value="Cat and Dog" <?php if (($app['current_pets'] ?? '') == "Cat and Dog") echo "selected"; ?>>Cat and Dog</option>
                    <option value="Other Pets" <?php if (($app['current_pets'] ?? '') == "Other Pets") echo "selected"; ?>>Other Pets</option>
                </select>

                <label>Does your family agree with this adoption?</label>
                <select name="family_agreement" required>
                    <option value="">Select answer</option>
                    <option value="Yes" <?php if (($app['family_agreement'] ?? '') == "Yes") echo "selected"; ?>>Yes</option>
                    <option value="No" <?php if (($app['family_agreement'] ?? '') == "No") echo "selected"; ?>>No</option>
                </select>

                <label>Are you willing to provide veterinary care when needed?</label>
                <select name="vet_agreement" required>
                    <option value="">Select answer</option>
                    <option value="Yes" <?php if (($app['vet_agreement'] ?? '') == "Yes") echo "selected"; ?>>Yes</option>
                    <option value="No" <?php if (($app['vet_agreement'] ?? '') == "No") echo "selected"; ?>>No</option>
                </select>

                <button type="submit" class="btn">Save Changes</button>

            </form>
        </div>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>