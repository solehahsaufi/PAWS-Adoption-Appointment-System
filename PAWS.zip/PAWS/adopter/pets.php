<?php
include("../includes/session.php");
checkAdopter();

include("../connection.php");
include("../includes/flash.php");

$search = isset($_GET['search']) ? trim($_GET['search']) : "";

function displayPetAge($birth_date, $fallback_age)
{
    if (!empty($birth_date)) {
        $birthDate = new DateTime($birth_date);
        $today = new DateTime();

        $diff = $birthDate->diff($today);
        $months = ($diff->y * 12) + $diff->m;

        if ($months < 1) {
            return "Less than 1 month";
        } elseif ($months == 1) {
            return "1 month";
        } elseif ($months < 12) {
            return $months . " months";
        } else {
            $years = floor($months / 12);
            $remainingMonths = $months % 12;

            if ($remainingMonths == 0) {
                return $years . ($years == 1 ? " year" : " years");
            }

            return $years . ($years == 1 ? " year " : " years ") . $remainingMonths . ($remainingMonths == 1 ? " month" : " months");
        }
    }

    return htmlspecialchars($fallback_age) . " months";
}

if ($search != "") {
    $keyword = "%" . $search . "%";

    $sql = "SELECT * FROM pet
            WHERE status = 'Available'
            AND (
                pet_name LIKE ?
                OR species LIKE ?
                OR breed LIKE ?
                OR gender LIKE ?
            )
            ORDER BY pet_id DESC";

    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        die("SQL Prepare Error: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "ssss", $keyword, $keyword, $keyword, $keyword);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

} else {

    $sql = "SELECT * FROM pet
            WHERE status = 'Available'
            ORDER BY pet_id DESC";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("SQL Error: " . mysqli_error($conn));
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Available Pets | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Available Pets</span>
    </div>

    <a href="dashboard.php" class="header-link">Back to Dashboard</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="page-title">
            <h1>Browse Available Pets</h1>
            <p>Select a pet first before booking an adoption appointment.</p>
        </div>

        <div class="notice-box">
            To book an appointment, please choose your preferred pet and click <strong>View Details</strong> or <strong>Book Appointment</strong>.
        </div>

        <div class="search-box">
            <form method="GET">
                <input 
                    type="text" 
                    name="search"
                    placeholder="Search by name, species, breed, or gender"
                    value="<?php echo htmlspecialchars($search); ?>"
                >

                <button type="submit" class="btn">Search</button>

                <a href="pets.php" class="btn btn-light">Reset</a>
            </form>
        </div>

        <?php if (mysqli_num_rows($result) == 0) { ?>

            <div class="empty-box">
                <h3>No Available Pet Found</h3>
                <p>There are no available pets matching your search at the moment.</p>
            </div>

        <?php } else { ?>

            <div class="pet-grid">

                <?php while ($row = mysqli_fetch_assoc($result)) { ?>

                    <div class="pet-card">

                        <?php if (!empty($row['image'])) { ?>
                            <img 
                                src="../images/pets/<?php echo htmlspecialchars($row['image']); ?>" 
                                alt="Pet Image"
                            >
                        <?php } else { ?>
                            <div style="height:210px; background:#dbeafe; display:flex; align-items:center; justify-content:center; color:#1d4ed8; font-weight:bold;">
                                PAWS
                            </div>
                        <?php } ?>

                        <div class="pet-card-body">

                            <h3><?php echo htmlspecialchars($row['pet_name']); ?></h3>

                            <p>
                                <strong>Species:</strong>
                                <?php echo htmlspecialchars($row['species']); ?>
                            </p>

                            <p>
                                <strong>Breed:</strong>
                                <?php echo htmlspecialchars($row['breed']); ?>
                            </p>

                            <p>
                                <strong>Gender:</strong>
                                <?php echo htmlspecialchars($row['gender']); ?>
                            </p>

                            <p>
                                <strong>Age:</strong>
                                <?php echo displayPetAge($row['estimated_birth_date'] ?? "", $row['age']); ?>
                            </p>

                            <p>
                                <strong>Vaccination:</strong>
                                <?php echo htmlspecialchars($row['vaccination']); ?>
                            </p>

                            <p>
                                <strong>Status:</strong>
                                <span class="status status-approved">Available</span>
                            </p>

                            <a href="pet_detail.php?id=<?php echo $row['pet_id']; ?>" class="btn">
                                View Details
                            </a>

                            <a href="appointment.php?pet_id=<?php echo $row['pet_id']; ?>" class="btn btn-light">
                                Book Appointment
                            </a>

                        </div>

                    </div>

                <?php } ?>

            </div>

        <?php } ?>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>