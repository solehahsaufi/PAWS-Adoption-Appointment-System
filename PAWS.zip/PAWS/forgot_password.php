<?php
session_start();

include("connection.php");
include("includes/flash.php");

$message = "";

function cleanPhoneNumber($phone)
{
    $phone = str_replace(" ", "", $phone);
    $phone = str_replace("-", "", $phone);
    return $phone;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    $phone_clean = str_replace(" ", "", $phone);
    $phone_digits = cleanPhoneNumber($phone);

    if ($email == "" || $phone == "" || $new_password == "" || $confirm_password == "") {
        $message = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address. Example: name@example.com";
    } elseif (!preg_match("/^01[0-9]-?[0-9]{7,8}$/", $phone_clean)) {
        $message = "Please enter a valid Malaysian mobile number. Example: 012-3456789 or 011-12345678.";
    } elseif ($new_password != $confirm_password) {
        $message = "New password and confirm password do not match.";
    } elseif (strlen($new_password) < 6) {
        $message = "Password must be at least 6 characters.";
    } else {

        $sql = "SELECT * FROM adopter
                WHERE email = ?
                AND (
                    phone = ?
                    OR REPLACE(phone, '-', '') = ?
                )";

        $stmt = mysqli_prepare($conn, $sql);

        if (!$stmt) {
            die("SQL Prepare Error: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt, "sss", $email, $phone, $phone_digits);
        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) == 1) {

            $adopter = mysqli_fetch_assoc($result);
            $adopter_id = $adopter['adopter_id'];

            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $update = "UPDATE adopter
                       SET password = ?
                       WHERE adopter_id = ?";

            $stmt_update = mysqli_prepare($conn, $update);

            if (!$stmt_update) {
                die("SQL Prepare Error: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param($stmt_update, "si", $hashed_password, $adopter_id);

            if (mysqli_stmt_execute($stmt_update)) {
                setFlashMessage("success", "Password reset successfully! Please login using your new password.");
                header("Location: login.php");
                exit();
            } else {
                die("SQL Execute Error: " . mysqli_stmt_error($stmt_update));
            }

        } else {
            $message = "The email address and phone number do not match any registered account.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password | PAWS</title>
    <link rel="stylesheet" href="css/dashboard.css">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="images/paws-logo.png" alt="PAWS Logo">
        <span>Forgot Password</span>
    </div>

    <a href="login.php" class="header-link">Back to Login</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card">
            <h2>Reset Password</h2>

            <div class="notice-box">
                Enter your registered email address and phone number to reset your password.
            </div>

            <?php
            if ($message != "") {
                echo "<div class='error-box'>$message</div>";
            }
            ?>

            <form method="POST" data-confirm-submit="Are you sure you want to reset your password?">

                <label>Registered Email Address</label>
                <input 
                    type="email" 
                    name="email" 
                    placeholder="Example: name@example.com" 
                    required
                >

                <label>Registered Phone Number</label>
                <input 
                    type="text" 
                    name="phone" 
                    placeholder="Example: 012-3456789 or 011-12345678"
                    pattern="^01[0-9]-?[0-9]{7,8}$"
                    title="Enter Malaysian mobile number, example: 012-3456789 or 011-12345678"
                    required
                >

                <label>New Password</label>
                <input 
                    type="password" 
                    name="new_password" 
                    placeholder="Enter new password" 
                    minlength="6"
                    required
                >

                <label>Confirm New Password</label>
                <input 
                    type="password" 
                    name="confirm_password" 
                    placeholder="Confirm new password" 
                    minlength="6"
                    required
                >

                <button type="submit" class="btn">Reset Password</button>

            </form>

            <p style="text-align:center; margin-top:18px;">
                Remember your password?
                <a href="login.php" style="color:#1d4ed8; font-weight:600;">Login here</a>
            </p>
        </div>

    </div>
</section>

<script src="js/ui-feedback.js"></script>

</body>
</html>