<?php
include("../includes/session.php");
checkStaff();

include("../connection.php");
include("../includes/flash.php");

$message = "";

function calculateAgeInMonths($birth_date)
{
    $birthDate = new DateTime($birth_date);
    $today = new DateTime();

    $diff = $birthDate->diff($today);
    return ($diff->y * 12) + $diff->m;
}

function displayPetAge($birth_date, $fallback_age)
{
    if (!empty($birth_date)) {
        $birthDate = new DateTime($birth_date);
        $today = new DateTime();
        $diff = $birthDate->diff($today);

        $months = ($diff->y * 12) + $diff->m;

        if ($months < 1) {
            return "Less than 1 month";
        } elseif ($months == 1) {
            return "1 month";
        } elseif ($months < 12) {
            return $months . " months";
        } else {
            $years = floor($months / 12);
            $remainingMonths = $months % 12;

            if ($remainingMonths == 0) {
                return $years . ($years == 1 ? " year" : " years");
            }

            return $years . ($years == 1 ? " year " : " years ") . $remainingMonths . ($remainingMonths == 1 ? " month" : " months");
        }
    }

    return htmlspecialchars($fallback_age) . " months";
}

if (!isset($_GET['id'])) {
    setFlashMessage("error", "Invalid pet record.");
    header("Location: manage_pet.php");
    exit();
}

$pet_id = intval($_GET['id']);

$sql = "SELECT * FROM pet WHERE pet_id = ?";
$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $pet_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    setFlashMessage("error", "Pet record not found.");
    header("Location: manage_pet.php");
    exit();
}

$pet = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $pet_name = trim($_POST['pet_name']);
    $species = trim($_POST['species']);
    $breed = trim($_POST['breed']);
    $gender = trim($_POST['gender']);
    $estimated_birth_date = trim($_POST['estimated_birth_date']);
    $vaccination = trim($_POST['vaccination']);
    $description = trim($_POST['description']);

    $image = $pet['image'];

    if (
        $pet_name == "" ||
        $species == "" ||
        $breed == "" ||
        $gender == "" ||
        $estimated_birth_date == "" ||
        $vaccination == "" ||
        $description == ""
    ) {
        $message = "Please fill in all required fields.";
    } elseif ($species != "Cat" && $species != "Dog") {
        $message = "Please select a valid pet species.";
    } elseif ($gender != "Male" && $gender != "Female") {
        $message = "Please select a valid gender.";
    } elseif (strtotime($estimated_birth_date) > strtotime(date("Y-m-d"))) {
        $message = "Estimated birth date cannot be in the future.";
    } else {

        $age = calculateAgeInMonths($estimated_birth_date);

        if (!empty($_FILES['image']['name'])) {

            $allowed_extensions = ["jpg", "jpeg", "png"];
            $file_name = $_FILES['image']['name'];
            $file_tmp = $_FILES['image']['tmp_name'];
            $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

            if (!in_array($file_extension, $allowed_extensions)) {
                $message = "Only JPG and PNG images are allowed.";
            } else {

                if (!is_dir("../images/pets")) {
                    mkdir("../images/pets", 0777, true);
                }

                $safe_name = preg_replace("/[^a-zA-Z0-9._-]/", "_", basename($file_name));
                $image = time() . "_" . $safe_name;
                $target = "../images/pets/" . $image;

                move_uploaded_file($file_tmp, $target);
            }
        }

        if ($message == "") {

            $update = "UPDATE pet
                       SET pet_name = ?,
                           species = ?,
                           breed = ?,
                           gender = ?,
                           age = ?,
                           estimated_birth_date = ?,
                           vaccination = ?,
                           description = ?,
                           image = ?
                       WHERE pet_id = ?";

            $stmt_update = mysqli_prepare($conn, $update);

            if (!$stmt_update) {
                die("SQL Prepare Error: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt_update,
                "ssssissssi",
                $pet_name,
                $species,
                $breed,
                $gender,
                $age,
                $estimated_birth_date,
                $vaccination,
                $description,
                $image,
                $pet_id
            );

            if (mysqli_stmt_execute($stmt_update)) {
                setFlashMessage("success", "Pet profile edited successfully!");
                header("Location: manage_pet.php");
                exit();
            } else {
                die("SQL Execute Error: " . mysqli_stmt_error($stmt_update));
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Pet Profile | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Edit Pet Profile</span>
    </div>

    <a href="manage_pet.php" class="header-link">Back to Manage Pets</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card">
            <h2>Edit Pet Profile</h2>

            <div class="notice-box">
                Edit pet information here. Pet age is calculated automatically based on the estimated birth date.
                Current pet status is controlled by the appointment and adoption process.
            </div>

            <?php
            if ($message != "") {
                echo "<div class='error-box'>$message</div>";
            }
            ?>

            <form method="POST" enctype="multipart/form-data" data-confirm-submit="Are you sure you want to save changes for this pet profile?">

                <label>Pet Name</label>
                <input 
                    type="text" 
                    name="pet_name"
                    value="<?php echo htmlspecialchars($pet['pet_name']); ?>"
                    required
                >

                <label>Species</label>
                <select name="species" id="species" required>
                    <option value="">Select species</option>
                    <option value="Cat" <?php if ($pet['species'] == "Cat") echo "selected"; ?>>Cat</option>
                    <option value="Dog" <?php if ($pet['species'] == "Dog") echo "selected"; ?>>Dog</option>
                </select>

                <label>Breed</label>
                <input 
                    type="text"
                    name="breed"
                    id="breed"
                    list="breedList"
                    placeholder="Select from list or type breed manually"
                    value="<?php echo htmlspecialchars($pet['breed']); ?>"
                    required
                >

                <datalist id="breedList"></datalist>

                <small style="color:#6b7280; display:block; margin-top:-8px; margin-bottom:12px;">
                    You can select from the suggestion list or type another breed if it is not listed.
                </small>

                <label>Gender</label>
                <select name="gender" required>
                    <option value="">Select gender</option>
                    <option value="Male" <?php if ($pet['gender'] == "Male") echo "selected"; ?>>Male</option>
                    <option value="Female" <?php if ($pet['gender'] == "Female") echo "selected"; ?>>Female</option>
                </select>

                <label>Estimated Birth Date</label>
                <input 
                    type="date" 
                    name="estimated_birth_date"
                    max="<?php echo date('Y-m-d'); ?>"
                    value="<?php echo htmlspecialchars($pet['estimated_birth_date'] ?? ""); ?>"
                    required
                >

                <div class="notice-box">
                    <strong>Current Age:</strong>
                    <?php echo displayPetAge($pet['estimated_birth_date'] ?? "", $pet['age']); ?>
                </div>

                <label>Vaccination Status</label>
                <select name="vaccination" required>
                    <option value="">Select vaccination status</option>
                    <option value="Completed" <?php if ($pet['vaccination'] == "Completed") echo "selected"; ?>>Completed</option>
                    <option value="Not Completed" <?php if ($pet['vaccination'] == "Not Completed") echo "selected"; ?>>Not Completed</option>
                    <option value="Partially Completed" <?php if ($pet['vaccination'] == "Partially Completed") echo "selected"; ?>>Partially Completed</option>
                </select>

                <label>Description</label>
                <textarea 
                    name="description"
                    required><?php echo htmlspecialchars($pet['description']); ?></textarea>

                <label>Current Status</label>
                <input 
                    type="text"
                    value="<?php echo htmlspecialchars($pet['status']); ?>"
                    readonly
                >

                <?php if (!empty($pet['image'])) { ?>
                    <label>Current Image</label>
                    <img 
                        src="../images/pets/<?php echo htmlspecialchars($pet['image']); ?>"
                        alt="Pet Image"
                        style="width:100%; max-height:250px; object-fit:cover; border-radius:16px; margin-bottom:15px;"
                    >
                <?php } ?>

                <label>Change Pet Image</label>
                <input 
                    type="file" 
                    name="image"
                    accept="image/png, image/jpeg, image/jpg"
                >

                <button type="submit" class="btn">Save Changes</button>

            </form>

        </div>

    </div>
</section>

<script>
const breedData = {
    "Cat": [
        "Domestic Short Hair",
        "Domestic Long Hair",
        "Persian",
        "Siamese",
        "Maine Coon",
        "Bengal",
        "British Shorthair",
        "Ragdoll",
        "Scottish Fold",
        "American Shorthair",
        "Mixed Breed"
    ],
    "Dog": [
        "Mixed Breed",
        "Labrador Retriever",
        "Golden Retriever",
        "Poodle",
        "German Shepherd",
        "Shih Tzu",
        "Beagle",
        "Husky",
        "Terrier",
        "Corgi",
        "Pomeranian",
        "Chihuahua"
    ]
};

const speciesSelect = document.getElementById("species");
const breedInput = document.getElementById("breed");
const breedList = document.getElementById("breedList");

function loadBreedSuggestions(species) {
    breedList.innerHTML = "";

    if (species === "" || !breedData[species]) {
        breedInput.placeholder = "Select species first";
        return;
    }

    breedInput.placeholder = "Select from list or type breed manually";

    breedData[species].forEach(function(breed) {
        const option = document.createElement("option");
        option.value = breed;
        breedList.appendChild(option);
    });
}

speciesSelect.addEventListener("change", function () {
    breedInput.value = "";
    loadBreedSuggestions(this.value);
});

loadBreedSuggestions(speciesSelect.value);
</script>

<script src="../js/ui-feedback.js"></script>

</body>
</html>