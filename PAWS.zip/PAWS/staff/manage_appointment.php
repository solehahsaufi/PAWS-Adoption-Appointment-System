<?php
include("../includes/session.php");
checkStaff();

include("../connection.php");
include("../includes/flash.php");

$status_filter = isset($_GET['status']) ? $_GET['status'] : "";

if ($status_filter != "") {
    $sql = "SELECT 
                appointment.*,
                TIME_FORMAT(appointment.appointment_time, '%H:%i') AS formatted_time,
                adopter.full_name AS adopter_name,
                adopter.email,
                adopter.phone,
                pet.pet_name,
                pet.species,
                pet.breed
            FROM appointment
            INNER JOIN adopter ON appointment.adopter_id = adopter.adopter_id
            INNER JOIN pet ON appointment.pet_id = pet.pet_id
            WHERE appointment.status = ?
            ORDER BY appointment.appointment_date DESC, appointment.appointment_time DESC";

    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $status_filter);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

} else {
    $sql = "SELECT 
                appointment.*,
                TIME_FORMAT(appointment.appointment_time, '%H:%i') AS formatted_time,
                adopter.full_name AS adopter_name,
                adopter.email,
                adopter.phone,
                pet.pet_name,
                pet.species,
                pet.breed
            FROM appointment
            INNER JOIN adopter ON appointment.adopter_id = adopter.adopter_id
            INNER JOIN pet ON appointment.pet_id = pet.pet_id
            ORDER BY appointment.appointment_date DESC, appointment.appointment_time DESC";

    $result = mysqli_query($conn, $sql);

    if (!$result) {
        die("SQL Error: " . mysqli_error($conn));
    }
}

function showAppointmentStatus($status)
{
    if ($status == "Pending") {
        return "<span class='status status-pending'>Pending Request</span>";
    } elseif ($status == "Approved") {
        return "<span class='status status-approved'>Approved</span>";
    } elseif ($status == "Rejected") {
        return "<span class='status status-rejected'>Rejected</span>";
    } elseif ($status == "Completed") {
        return "<span class='status status-approved'>Completed</span>";
    } elseif ($status == "Cancelled") {
        return "<span class='status status-rejected'>Cancelled</span>";
    } else {
        return "<span class='status'>" . htmlspecialchars($status) . "</span>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Appointment Requests | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Manage Appointment Requests</span>
    </div>

    <a href="dashboard.php" class="header-link">Back to Dashboard</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="page-title">
            <h1>Manage Appointment Requests</h1>
            <p>Review adopter booking requests and decide whether to approve or reject them.</p>
        </div>

        <div class="search-box">
            <form method="GET">
                <select name="status">
                    <option value="">All Status</option>
                    <option value="Pending" <?php if ($status_filter == "Pending") echo "selected"; ?>>Pending</option>
                    <option value="Approved" <?php if ($status_filter == "Approved") echo "selected"; ?>>Approved</option>
                    <option value="Rejected" <?php if ($status_filter == "Rejected") echo "selected"; ?>>Rejected</option>
                    <option value="Cancelled" <?php if ($status_filter == "Cancelled") echo "selected"; ?>>Cancelled</option>
                </select>

                <button type="submit" class="btn">Filter</button>

                <a href="manage_appointment.php" class="btn btn-light">Reset</a>
            </form>
        </div>

        <?php if (mysqli_num_rows($result) == 0) { ?>

            <div class="empty-box">
                <h3>No Appointment Request Found</h3>
                <p>There are no appointment records for the selected status.</p>
            </div>

        <?php } else { ?>

            <div class="table-card">
                <table>
                    <tr>
                        <th>Adopter</th>
                        <th>Pet</th>
                        <th>Date & Time</th>
                        <th>Reason</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>

                    <?php while ($row = mysqli_fetch_assoc($result)) { ?>

                        <tr>
                            <td>
                                <strong><?php echo htmlspecialchars($row['adopter_name']); ?></strong>
                                <br>
                                <small><?php echo htmlspecialchars($row['email']); ?></small>
                                <br>
                                <small><?php echo htmlspecialchars($row['phone']); ?></small>
                            </td>

                            <td>
                                <strong><?php echo htmlspecialchars($row['pet_name']); ?></strong>
                                <br>
                                <small>
                                    <?php echo htmlspecialchars($row['species']); ?> |
                                    <?php echo htmlspecialchars($row['breed']); ?>
                                </small>
                            </td>

                            <td>
                                <?php echo date("d M Y", strtotime($row['appointment_date'])); ?>
                                <br>
                                <?php echo date("h:i A", strtotime($row['formatted_time'])); ?>
                            </td>

                            <td>
                                <?php echo htmlspecialchars($row['appointment_reason']); ?>

                                <?php if (!empty($row['appointment_notes'])) { ?>
                                    <br>
                                    <small>
                                        Notes: <?php echo htmlspecialchars($row['appointment_notes']); ?>
                                    </small>
                                <?php } ?>
                            </td>

                            <td>
                                <?php echo showAppointmentStatus($row['status']); ?>
                            </td>

                            <td>
                                <?php if ($row['status'] == "Pending") { ?>

                                    <a 
                                        href="update_appointment_status.php?id=<?php echo $row['appointment_id']; ?>&action=approve"
                                        class="btn btn-green"
                                        data-confirm="Are you sure you want to approve this appointment booking?"
                                    >
                                        Approve
                                    </a>

                                    <br><br>

                                    <a 
                                        href="update_appointment_status.php?id=<?php echo $row['appointment_id']; ?>&action=reject"
                                        class="btn btn-red"
                                        data-confirm="Are you sure you want to reject this appointment booking?"
                                    >
                                        Reject
                                    </a>

                                <?php } elseif ($row['status'] == "Approved") { ?>

                                    <span style="color:#6b7280; font-size:14px;">
                                        Booking approved
                                    </span>

                                <?php } elseif ($row['status'] == "Rejected") { ?>

                                    <span style="color:#6b7280; font-size:14px;">
                                        Booking rejected
                                    </span>

                                <?php } elseif ($row['status'] == "Cancelled") { ?>

                                    <span style="color:#6b7280; font-size:14px;">
                                        Cancelled by adopter
                                    </span>

                                <?php } else { ?>

                                    <span style="color:#6b7280; font-size:14px;">
                                        No action
                                    </span>

                                <?php } ?>
                            </td>
                        </tr>

                    <?php } ?>
                </table>
            </div>

        <?php } ?>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>