<?php
include("../includes/session.php");
checkStaff();

include("../connection.php");
include("../includes/flash.php");

if (!isset($_GET['id'])) {
    setFlashMessage("error", "Invalid pet record.");
    header("Location: manage_pet.php");
    exit();
}

$pet_id = intval($_GET['id']);

/* Check if pet exists */
$sql_pet = "SELECT * FROM pet WHERE pet_id = ?";
$stmt_pet = mysqli_prepare($conn, $sql_pet);

if (!$stmt_pet) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_pet, "i", $pet_id);
mysqli_stmt_execute($stmt_pet);

$result_pet = mysqli_stmt_get_result($stmt_pet);

if (mysqli_num_rows($result_pet) != 1) {
    setFlashMessage("error", "Pet record not found.");
    header("Location: manage_pet.php");
    exit();
}

$pet = mysqli_fetch_assoc($result_pet);

/* Check if pet has appointment history */
$sql_appointment = "SELECT COUNT(*) AS total_appointment 
                    FROM appointment 
                    WHERE pet_id = ?";

$stmt_appointment = mysqli_prepare($conn, $sql_appointment);

if (!$stmt_appointment) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_appointment, "i", $pet_id);
mysqli_stmt_execute($stmt_appointment);

$result_appointment = mysqli_stmt_get_result($stmt_appointment);
$appointment_data = mysqli_fetch_assoc($result_appointment);

$total_appointment = $appointment_data['total_appointment'];

/* Check if pet has adoption application history */
$sql_application = "SELECT COUNT(*) AS total_application 
                    FROM adoption_application 
                    WHERE pet_id = ?";

$stmt_application = mysqli_prepare($conn, $sql_application);

if (!$stmt_application) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_application, "i", $pet_id);
mysqli_stmt_execute($stmt_application);

$result_application = mysqli_stmt_get_result($stmt_application);
$application_data = mysqli_fetch_assoc($result_application);

$total_application = $application_data['total_application'];

/* Prevent deletion if pet has history */
if ($total_appointment > 0 || $total_application > 0) {
    setFlashMessage(
        "error", 
        "This pet record cannot be deleted because it has appointment or adoption history. The record must be kept for tracking and reporting purposes."
    );

    header("Location: manage_pet.php");
    exit();
}

/* Delete only if no appointment/application history */
$sql_delete = "DELETE FROM pet WHERE pet_id = ?";
$stmt_delete = mysqli_prepare($conn, $sql_delete);

if (!$stmt_delete) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt_delete, "i", $pet_id);

if (mysqli_stmt_execute($stmt_delete)) {

    if (!empty($pet['image'])) {
        $image_path = "../images/pets/" . $pet['image'];

        if (file_exists($image_path)) {
            unlink($image_path);
        }
    }

    setFlashMessage("success", "Pet record deleted successfully.");

} else {
    setFlashMessage("error", "Failed to delete pet record.");
}

header("Location: manage_pet.php");
exit();
?>