<?php
include("../includes/session.php");
checkStaff();
include("../connection.php");
include("../includes/flash.php");

$search = "";

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);

    $sql = "SELECT adoption_application.*, 
                   adopter.full_name, adopter.email, adopter.phone,
                   pet.pet_name, pet.species, pet.breed
            FROM adoption_application
            JOIN adopter ON adoption_application.adopter_id = adopter.adopter_id
            JOIN pet ON adoption_application.pet_id = pet.pet_id
            WHERE adopter.full_name LIKE ?
               OR pet.pet_name LIKE ?
               OR adoption_application.status LIKE ?
            ORDER BY adoption_application.application_id DESC";

    $stmt = mysqli_prepare($conn, $sql);
    $like = "%" . $search . "%";
    mysqli_stmt_bind_param($stmt, "sss", $like, $like, $like);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

} else {
    $sql = "SELECT adoption_application.*, 
                   adopter.full_name, adopter.email, adopter.phone,
                   pet.pet_name, pet.species, pet.breed
            FROM adoption_application
            JOIN adopter ON adoption_application.adopter_id = adopter.adopter_id
            JOIN pet ON adoption_application.pet_id = pet.pet_id
            ORDER BY adoption_application.application_id DESC";

    $result = mysqli_query($conn, $sql);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Applications | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Manage Adoption Applications</span>
    </div>
    <a href="dashboard.php" class="header-link">Back to Dashboard</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <h2 class="page-title">Adoption Applications</h2>
        <p class="page-subtitle">Review adopter details and update application status.</p>

        <form method="GET" class="search-box">
            <input type="text" name="search" placeholder="Search adopter, pet name, or status"
                   value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit" class="btn">Search</button>
            <a href="manage_application.php" class="btn">Reset</a>
        </form>

        <div class="table-card">
            <table>
                <tr>
                    <th>No</th>
                    <th>Adopter Name</th>
                    <th>Pet Name</th>
                    <th>Species</th>
                    <th>Application Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>

                <?php
                $no = 1;

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                ?>

                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['pet_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['species']); ?></td>
                    <td><?php echo htmlspecialchars($row['application_date']); ?></td>

                    <td>
                        <?php
                        if ($row['status'] == "Pending") {
                            echo "<span class='status status-pending'>Pending</span>";
                        } elseif ($row['status'] == "Approved") {
                            echo "<span class='status status-approved'>Approved</span>";
                        } elseif ($row['status'] == "Rejected") {
                            echo "<span class='status status-rejected'>Rejected</span>";
                        } else {
                            echo htmlspecialchars($row['status']);
                        }
                        ?>
                    </td>

                    <td>
                        <a href="application_details.php?id=<?php echo $row['application_id']; ?>" class="btn">
                            View Details
                        </a>
                    </td>
                </tr>

                <?php
                    }
                } else {
                    echo "<tr><td colspan='7'>No adoption applications found.</td></tr>";
                }
                ?>

            </table>
        </div>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>