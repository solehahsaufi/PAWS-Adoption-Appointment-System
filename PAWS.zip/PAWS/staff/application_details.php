<?php
include("../includes/session.php");
checkStaff();
include("../connection.php");

if (!isset($_GET['id'])) {
    header("Location: manage_application.php");
    exit();
}

$application_id = $_GET['id'];

$sql = "SELECT adoption_application.*, 
               adopter.full_name, adopter.email, adopter.phone, adopter.address,
               pet.pet_name, pet.species, pet.breed, pet.age, pet.gender, pet.vaccination
        FROM adoption_application
        JOIN adopter ON adoption_application.adopter_id = adopter.adopter_id
        JOIN pet ON adoption_application.pet_id = pet.pet_id
        WHERE adoption_application.application_id = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $application_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    header("Location: manage_application.php");
    exit();
}

$app = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Application Details | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Application Details</span>
    </div>
    <a href="manage_application.php" class="header-link">Back</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card" style="width:700px;">
            <h2>Adoption Application Details</h2>

            <div class="notice-box">
                Staff should review the adopter information and pet suitability before approving or rejecting the application.
            </div>

            <h3 style="color:#1d4ed8; margin-bottom:10px;">Adopter Information</h3>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($app['full_name'] ?? 'Not provided'); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($app['email'] ?? 'Not provided'); ?></p>
            <p><strong>Phone:</strong> <?php echo htmlspecialchars($app['phone'] ?? 'Not provided'); ?></p>
            <p><strong>Address:</strong> <?php echo htmlspecialchars($app['address'] ?? 'Not provided'); ?></p>

            <br>

            <h3 style="color:#1d4ed8; margin-bottom:10px;">Pet Information</h3>
            <p><strong>Pet Name:</strong> <?php echo htmlspecialchars($app['pet_name'] ?? 'Not provided'); ?></p>
            <p><strong>Species:</strong> <?php echo htmlspecialchars($app['species'] ?? 'Not provided'); ?></p>
            <p><strong>Breed:</strong> <?php echo htmlspecialchars($app['breed'] ?? 'Not provided'); ?></p>
            <p><strong>Age:</strong> <?php echo htmlspecialchars($app['age'] ?? 'Not provided'); ?> months</p>
            <p><strong>Gender:</strong> <?php echo htmlspecialchars($app['gender'] ?? 'Not provided'); ?></p>
            <p><strong>Vaccination:</strong> <?php echo htmlspecialchars($app['vaccination'] ?? 'Not provided'); ?></p>

            <br>

            <h3 style="color:#1d4ed8; margin-bottom:10px;">Application Information</h3>
            <p><strong>Application Date:</strong> <?php echo htmlspecialchars($app['application_date'] ?? 'Not provided'); ?></p>
            <p><strong>Status:</strong> <?php echo htmlspecialchars($app['status'] ?? 'Not provided'); ?></p>

            <br>

            <p><strong>Reason for Adoption:</strong></p>
            <p style="line-height:1.6;">
                <?php echo nl2br(htmlspecialchars($app['reason'] ?? 'Not provided')); ?>
            </p>

            <br>

            <p><strong>Housing Type:</strong> <?php echo htmlspecialchars($app['housing_type'] ?? 'Not provided'); ?></p>
            <p><strong>Pet Care Experience:</strong> <?php echo htmlspecialchars($app['pet_experience'] ?? 'Not provided'); ?></p>
            <p><strong>Current Pets at Home:</strong> <?php echo htmlspecialchars($app['current_pets'] ?? 'Not provided'); ?></p>
            <p><strong>Family Agreement:</strong> <?php echo htmlspecialchars($app['family_agreement'] ?? 'Not provided'); ?></p>
            <p><strong>Veterinary Care Agreement:</strong> <?php echo htmlspecialchars($app['vet_agreement'] ?? 'Not provided'); ?></p>

            <br>

            <?php if ($app['status'] == "Pending") { ?>

                <a href="update_application_status.php?id=<?php echo $app['application_id']; ?>&action=approve"
                   class="btn btn-green"
                   data-confirm="Are you sure you want to approve this adoption application?">
                   Approve Application
                </a>

                <a href="update_application_status.php?id=<?php echo $app['application_id']; ?>&action=reject"
                   class="btn btn-red"
                   data-confirm="Are you sure you want to reject this adoption application? The pet will become available again.">
                   Reject Application
                </a>

            <?php } else { ?>

                <div class="notice-box">
                    This application has already been reviewed. No further action is required.
                </div>

            <?php } ?>

        </div>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>