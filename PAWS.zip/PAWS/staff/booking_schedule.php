<?php
include("../includes/session.php");
checkStaff();

include("../connection.php");
include("../includes/flash.php");

$selected_date = isset($_GET['date']) ? $_GET['date'] : date("Y-m-d");

$all_slots = [
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "13:00",
    "14:00",
    "15:00"
];

$sql = "SELECT 
            appointment.*,
            TIME_FORMAT(appointment.appointment_time, '%H:%i') AS formatted_time,
            adopter.full_name AS adopter_name,
            adopter.phone,
            pet.pet_name,
            pet.species,
            pet.breed
        FROM appointment
        INNER JOIN adopter ON appointment.adopter_id = adopter.adopter_id
        INNER JOIN pet ON appointment.pet_id = pet.pet_id
        WHERE appointment.appointment_date = ?
        ORDER BY appointment.appointment_time ASC";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $selected_date);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$appointments_by_time = [];

while ($row = mysqli_fetch_assoc($result)) {
    $appointments_by_time[$row['formatted_time']] = $row;
}

function showAppointmentStatusSchedule($status)
{
    if ($status == "Pending") {
        return "<span class='status status-pending'>Pending Request</span>";
    } elseif ($status == "Approved") {
        return "<span class='status status-approved'>Approved</span>";
    } elseif ($status == "Rejected") {
        return "<span class='status status-rejected'>Rejected</span>";
    } elseif ($status == "Completed") {
        return "<span class='status status-approved'>Completed</span>";
    } elseif ($status == "Cancelled") {
        return "<span class='status status-rejected'>Cancelled</span>";
    } else {
        return "<span class='status'>" . htmlspecialchars($status) . "</span>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Booking Schedule | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Booking Schedule</span>
    </div>

    <a href="dashboard.php" class="header-link">Back to Dashboard</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="page-title">
            <h1>Booking Schedule</h1>
            <p>Select a date to view all appointment booking slots for that day.</p>
        </div>

        <div class="search-box">
            <form method="GET">
                <input 
                    type="date" 
                    name="date"
                    value="<?php echo htmlspecialchars($selected_date); ?>"
                    required
                >

                <button type="submit" class="btn">View Schedule</button>

                <a href="booking_schedule.php?date=<?php echo date('Y-m-d'); ?>" class="btn btn-light">
                    Today
                </a>
            </form>
        </div>

        <div class="notice-box">
            <strong>Selected Date:</strong>
            <?php echo date("d M Y", strtotime($selected_date)); ?>

            <?php if (date("w", strtotime($selected_date)) == 3) { ?>
                <br>
                <strong>Note:</strong> PAWS is closed every Wednesday.
            <?php } ?>
        </div>

        <div class="table-card">
            <table>
                <tr>
                    <th>Time Slot</th>
                    <th>Slot Status</th>
                    <th>Pet</th>
                    <th>Adopter</th>
                    <th>Appointment Status</th>
                </tr>

                <?php foreach ($all_slots as $slot) { ?>

                    <tr>
                        <td>
                            <strong><?php echo date("h:i A", strtotime($slot)); ?></strong>
                        </td>

                        <?php if (isset($appointments_by_time[$slot])) { 
                            $row = $appointments_by_time[$slot];
                        ?>

                            <td>
                                <span class="status status-pending">Booked Slot</span>
                            </td>

                            <td>
                                <strong><?php echo htmlspecialchars($row['pet_name']); ?></strong>
                                <br>
                                <small>
                                    <?php echo htmlspecialchars($row['species']); ?> |
                                    <?php echo htmlspecialchars($row['breed']); ?>
                                </small>
                            </td>

                            <td>
                                <strong><?php echo htmlspecialchars($row['adopter_name']); ?></strong>
                                <br>
                                <small><?php echo htmlspecialchars($row['phone']); ?></small>
                            </td>

                            <td>
                                <?php echo showAppointmentStatusSchedule($row['status']); ?>
                            </td>

                        <?php } else { ?>

                            <td>
                                <span class="status status-approved">Available</span>
                            </td>

                            <td>-</td>
                            <td>-</td>
                            <td>
                                <span style="color:#6b7280; font-size:14px;">No booking</span>
                            </td>

                        <?php } ?>

                    </tr>

                <?php } ?>
            </table>
        </div>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>