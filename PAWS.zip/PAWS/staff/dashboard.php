<?php
include("../includes/session.php");
checkStaff();

include("../connection.php");
include("../includes/flash.php");

$staff_id = $_SESSION['staff_id'];
$staff_name = $_SESSION['staff_name'] ?? "Staff";

$sql = "SELECT full_name, username, role FROM staff WHERE staff_id = ?";
$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $staff_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
$staff = mysqli_fetch_assoc($result);

$full_name = $staff['full_name'] ?? $staff_name;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Staff Dashboard | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>PAWS Staff Portal</span>
    </div>

    <a href="profile.php" class="profile-header-btn" title="Staff Account">
        <span><?php echo strtoupper(substr($full_name, 0, 1)); ?></span>
    </a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="dashboard-hero">
            <div class="dashboard-hero-content">
                <span class="dashboard-hero-badge">
                    Welcome, <?php echo htmlspecialchars($full_name); ?>
                </span>

                <h1>Manage Adoption Operations Efficiently</h1>

                <p>
                    This staff portal helps PAWS manage pet records, review appointment booking 
                    requests, monitor booking schedules, and process adoption applications in 
                    a more organised way.
                </p>

                <a href="manage_appointment.php" class="btn">Review Appointment Requests</a>
            </div>
        </div>

        <div class="page-title">
            <h1>Staff Dashboard</h1>
            <p>Select a management module below.</p>
        </div>

        <div class="dashboard-action-grid">

            <div class="dashboard-action-card">
                <h3>Manage Pets</h3>
                <p>
                    Add, update, delete, and monitor pet records and pet availability status.
                </p>
                <a href="manage_pet.php" class="btn">Manage Pets</a>
            </div>

            <div class="dashboard-action-card">
                <h3>Manage Appointments</h3>
                <p>
                    Review adopter appointment requests and approve or reject booking requests.
                </p>
                <a href="manage_appointment.php" class="btn">Manage Appointments</a>
            </div>

            <div class="dashboard-action-card">
                <h3>Booking Schedule</h3>
                <p>
                    View appointment booking slots based on selected date and time.
                </p>
                <a href="booking_schedule.php" class="btn">View Schedule</a>
            </div>

            <div class="dashboard-action-card">
                <h3>Manage Applications</h3>
                <p>
                    Review adoption applications and approve or reject adoption requests.
                </p>
                <a href="manage_application.php" class="btn">Manage Applications</a>
            </div>

        </div>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>