<?php
include("../includes/session.php");
checkStaff();

include("../connection.php");
include("../includes/flash.php");

if (!isset($_GET['id']) || !isset($_GET['action'])) {
    setFlashMessage("error", "Invalid appointment action.");
    header("Location: manage_appointment.php");
    exit();
}

$appointment_id = intval($_GET['id']);
$action = $_GET['action'];

$valid_actions = ["approve", "reject"];

if (!in_array($action, $valid_actions)) {
    setFlashMessage("error", "Invalid appointment action.");
    header("Location: manage_appointment.php");
    exit();
}

mysqli_begin_transaction($conn);

$sql = "SELECT * FROM appointment WHERE appointment_id = ? FOR UPDATE";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $appointment_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    mysqli_rollback($conn);
    setFlashMessage("error", "Appointment record not found.");
    header("Location: manage_appointment.php");
    exit();
}

$appointment = mysqli_fetch_assoc($result);
$current_status = $appointment['status'];
$pet_id = $appointment['pet_id'];

if ($current_status != "Pending") {
    mysqli_rollback($conn);
    setFlashMessage("error", "Only pending appointment requests can be updated.");
    header("Location: manage_appointment.php");
    exit();
}

if ($action == "approve") {
    $new_status = "Approved";
    $new_pet_status = "Booked";
    $success_message = "Appointment booking approved successfully.";
} else {
    $new_status = "Rejected";
    $new_pet_status = "Available";
    $success_message = "Appointment booking rejected successfully.";
}

$update_appointment = "UPDATE appointment
                       SET status = ?
                       WHERE appointment_id = ?";

$stmt_update = mysqli_prepare($conn, $update_appointment);
mysqli_stmt_bind_param($stmt_update, "si", $new_status, $appointment_id);
$ok1 = mysqli_stmt_execute($stmt_update);

$update_pet = "UPDATE pet
               SET status = ?
               WHERE pet_id = ?";

$stmt_pet = mysqli_prepare($conn, $update_pet);
mysqli_stmt_bind_param($stmt_pet, "si", $new_pet_status, $pet_id);
$ok2 = mysqli_stmt_execute($stmt_pet);

if ($ok1 && $ok2) {
    mysqli_commit($conn);
    setFlashMessage("success", $success_message);
} else {
    mysqli_rollback($conn);
    setFlashMessage("error", "Failed to update appointment status.");
}

header("Location: manage_appointment.php");
exit();
?>