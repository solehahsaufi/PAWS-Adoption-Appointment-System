<?php
include("../includes/session.php");
checkStaff();

include("../connection.php");
include("../includes/flash.php");

$staff_id = $_SESSION['staff_id'];
$message = "";

$sql = "SELECT * FROM staff WHERE staff_id = ?";
$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die("SQL Prepare Error: " . mysqli_error($conn));
}

mysqli_stmt_bind_param($stmt, "i", $staff_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    setFlashMessage("error", "Staff account not found.");
    header("Location: dashboard.php");
    exit();
}

$staff = mysqli_fetch_assoc($result);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $current_password = trim($_POST['current_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_new_password = trim($_POST['confirm_new_password']);

    if ($current_password == "" || $new_password == "" || $confirm_new_password == "") {
        $message = "Please fill in all password fields.";
    } elseif (!password_verify($current_password, $staff['password'])) {
        $message = "Current password is incorrect.";
    } elseif ($new_password != $confirm_new_password) {
        $message = "New password and confirm new password do not match.";
    } elseif (strlen($new_password) < 6) {
        $message = "New password must be at least 6 characters.";
    } else {

        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        $update = "UPDATE staff
                   SET password = ?
                   WHERE staff_id = ?";

        $stmt_update = mysqli_prepare($conn, $update);

        if (!$stmt_update) {
            die("SQL Prepare Error: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt_update, "si", $hashed_password, $staff_id);

        if (mysqli_stmt_execute($stmt_update)) {
            setFlashMessage("success", "Password changed successfully!");
            header("Location: profile.php");
            exit();
        } else {
            $message = "Failed to change password.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Staff Account | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Staff Account</span>
    </div>

    <div style="display:flex; gap:10px; align-items:center;">
        <a href="dashboard.php" class="header-link">Back to Dashboard</a>

        <a 
            href="../logout.php" 
            class="header-link logout-btn"
            data-confirm="Are you sure you want to logout from staff portal?"
        >
            Logout
        </a>
    </div>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card" style="width:620px;">

            <h2>Staff Account</h2>

            <div class="notice-box">
                Staff account details are managed by the administrator. 
                Staff can only change their own password and logout from the system.
            </div>

            <?php
            if ($message != "") {
                echo "<div class='error-box'>$message</div>";
            }
            ?>

            <h3 class="profile-section-title">Account Details</h3>

            <div class="table-card" style="margin-bottom:25px;">
                <table>
                    <tr>
                        <th>Field</th>
                        <th>Details</th>
                    </tr>

                    <tr>
                        <td>Full Name</td>
                        <td><?php echo htmlspecialchars($staff['full_name']); ?></td>
                    </tr>

                    <tr>
                        <td>Username</td>
                        <td><?php echo htmlspecialchars($staff['username']); ?></td>
                    </tr>

                    <tr>
                        <td>Role</td>
                        <td><?php echo htmlspecialchars($staff['role']); ?></td>
                    </tr>
                </table>
            </div>

            <h3 class="profile-section-title">Change Password</h3>

            <form method="POST" data-confirm-submit="Are you sure you want to change your password?">

                <label>Current Password</label>
                <input 
                    type="password" 
                    name="current_password"
                    placeholder="Enter current password"
                    required
                >

                <label>New Password</label>
                <input 
                    type="password" 
                    name="new_password"
                    placeholder="Enter new password"
                    minlength="6"
                    required
                >

                <label>Confirm New Password</label>
                <input 
                    type="password" 
                    name="confirm_new_password"
                    placeholder="Confirm new password"
                    minlength="6"
                    required
                >

                <button type="submit" class="btn">Change Password</button>

            </form>

        </div>

    </div>
</section>

<script src="../js/ui-feedback.js"></script>

</body>
</html>