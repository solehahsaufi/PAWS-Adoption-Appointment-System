<?php
include("../includes/session.php");
checkStaff();
include("../connection.php");
include("../includes/flash.php");

if (!isset($_GET['id']) || !isset($_GET['action'])) {
    setFlashMessage("error", "Invalid application action.");
    header("Location: manage_application.php");
    exit();
}

$application_id = $_GET['id'];
$action = $_GET['action'];

$sql = "SELECT * FROM adoption_application
        WHERE application_id = ?
        AND status = 'Pending'";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $application_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) != 1) {
    setFlashMessage("error", "This application cannot be updated.");
    header("Location: manage_application.php");
    exit();
}

$app = mysqli_fetch_assoc($result);
$pet_id = $app['pet_id'];
$appointment_id = $app['appointment_id'];

if ($action == "approve") {
    $new_status = "Approved";
    $pet_status = "Adopted";
    $message = "Application approved successfully.";
} elseif ($action == "reject") {
    $new_status = "Rejected";
    $pet_status = "Available";
    $message = "Application rejected successfully.";
} else {
    setFlashMessage("error", "Invalid application action.");
    header("Location: manage_application.php");
    exit();
}

mysqli_begin_transaction($conn);

$update_app = "UPDATE adoption_application SET status = ? WHERE application_id = ?";
$stmt_app = mysqli_prepare($conn, $update_app);
mysqli_stmt_bind_param($stmt_app, "si", $new_status, $application_id);
$ok1 = mysqli_stmt_execute($stmt_app);

$update_pet = "UPDATE pet SET status = ? WHERE pet_id = ?";
$stmt_pet = mysqli_prepare($conn, $update_pet);
mysqli_stmt_bind_param($stmt_pet, "si", $pet_status, $pet_id);
$ok2 = mysqli_stmt_execute($stmt_pet);

$update_appointment = "UPDATE appointment SET status = 'Completed' WHERE appointment_id = ?";
$stmt_appointment = mysqli_prepare($conn, $update_appointment);
mysqli_stmt_bind_param($stmt_appointment, "i", $appointment_id);
$ok3 = mysqli_stmt_execute($stmt_appointment);

if ($ok1 && $ok2 && $ok3) {
    mysqli_commit($conn);
    setFlashMessage("success", $message);
    header("Location: manage_application.php");
    exit();
} else {
    mysqli_rollback($conn);
    setFlashMessage("error", "Failed to update application status.");
    header("Location: manage_application.php");
    exit();
}
?>