<?php
include("../includes/session.php");
checkStaff();

include("../connection.php");
include("../includes/flash.php");

$message = "";

function oldValue($field)
{
    return isset($_POST[$field]) ? htmlspecialchars($_POST[$field]) : "";
}

function calculateAgeInMonths($birth_date)
{
    $birthDate = new DateTime($birth_date);
    $today = new DateTime();

    $diff = $birthDate->diff($today);
    return ($diff->y * 12) + $diff->m;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $pet_name = trim($_POST['pet_name']);
    $species = trim($_POST['species']);
    $breed = trim($_POST['breed']);
    $gender = trim($_POST['gender']);
    $estimated_birth_date = trim($_POST['estimated_birth_date']);
    $vaccination = trim($_POST['vaccination']);
    $description = trim($_POST['description']);

    $image = "";

    if (
        $pet_name == "" ||
        $species == "" ||
        $breed == "" ||
        $gender == "" ||
        $estimated_birth_date == "" ||
        $vaccination == "" ||
        $description == ""
    ) {
        $message = "Please fill in all required fields.";
    } elseif ($species != "Cat" && $species != "Dog") {
        $message = "Please select a valid pet species.";
    } elseif ($gender != "Male" && $gender != "Female") {
        $message = "Please select a valid gender.";
    } elseif (strtotime($estimated_birth_date) > strtotime(date("Y-m-d"))) {
        $message = "Estimated birth date cannot be in the future.";
    } else {

        $age = calculateAgeInMonths($estimated_birth_date);

        if (!empty($_FILES['image']['name'])) {

            $allowed_extensions = ["jpg", "jpeg", "png"];
            $file_name = $_FILES['image']['name'];
            $file_tmp = $_FILES['image']['tmp_name'];
            $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

            if (!in_array($file_extension, $allowed_extensions)) {
                $message = "Only JPG and PNG images are allowed.";
            } else {

                if (!is_dir("../images/pets")) {
                    mkdir("../images/pets", 0777, true);
                }

                $safe_name = preg_replace("/[^a-zA-Z0-9._-]/", "_", basename($file_name));
                $image = time() . "_" . $safe_name;
                $target = "../images/pets/" . $image;

                move_uploaded_file($file_tmp, $target);
            }
        }

        if ($message == "") {

            $sql = "INSERT INTO pet
                    (pet_name, species, breed, gender, age, estimated_birth_date, vaccination, description, status, image)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Available', ?)";

            $stmt = mysqli_prepare($conn, $sql);

            if (!$stmt) {
                die("SQL Prepare Error: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt,
                "ssssissss",
                $pet_name,
                $species,
                $breed,
                $gender,
                $age,
                $estimated_birth_date,
                $vaccination,
                $description,
                $image
            );

            if (mysqli_stmt_execute($stmt)) {
                setFlashMessage("success", "Pet record added successfully!");
                header("Location: manage_pet.php");
                exit();
            } else {
                die("SQL Execute Error: " . mysqli_stmt_error($stmt));
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Pet | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css?v=20">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Add New Pet</span>
    </div>

    <a href="manage_pet.php" class="header-link">Back to Manage Pets</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card">
            <h2>Add New Pet</h2>

            <div class="notice-box">
                Add pet details into the PAWS adoption system. Pet status will automatically be set as Available.
            </div>

            <?php
            if ($message != "") {
                echo "<div class='error-box'>$message</div>";
            }
            ?>

            <form method="POST" enctype="multipart/form-data" data-confirm-submit="Are you sure you want to add this pet record?">

                <label>Pet Name</label>
                <input 
                    type="text" 
                    name="pet_name"
                    placeholder="Example: Luna"
                    value="<?php echo oldValue('pet_name'); ?>"
                    required
                >

                <label>Species</label>
                <select name="species" id="species" required>
                    <option value="">Select species</option>
                    <option value="Cat" <?php if (oldValue('species') == "Cat") echo "selected"; ?>>Cat</option>
                    <option value="Dog" <?php if (oldValue('species') == "Dog") echo "selected"; ?>>Dog</option>
                </select>

                <label>Breed</label>
                <input 
                    type="text"
                    name="breed"
                    id="breed"
                    list="breedList"
                    placeholder="Select species first"
                    value="<?php echo oldValue('breed'); ?>"
                    required
                >

                <datalist id="breedList"></datalist>

                <small style="color:#6b7280; display:block; margin-top:-8px; margin-bottom:12px;">
                    You can select from the suggestion list or type another breed if it is not listed.
                </small>

                <label>Gender</label>
                <select name="gender" required>
                    <option value="">Select gender</option>
                    <option value="Male" <?php if (oldValue('gender') == "Male") echo "selected"; ?>>Male</option>
                    <option value="Female" <?php if (oldValue('gender') == "Female") echo "selected"; ?>>Female</option>
                </select>

                <label>Estimated Birth Date</label>
                <input 
                    type="date" 
                    name="estimated_birth_date"
                    max="<?php echo date('Y-m-d'); ?>"
                    value="<?php echo oldValue('estimated_birth_date'); ?>"
                    required
                >

                <label>Vaccination Status</label>
                <select name="vaccination" required>
                    <option value="">Select vaccination status</option>
                    <option value="Completed" <?php if (oldValue('vaccination') == "Completed") echo "selected"; ?>>Completed</option>
                    <option value="Not Completed" <?php if (oldValue('vaccination') == "Not Completed") echo "selected"; ?>>Not Completed</option>
                    <option value="Partially Completed" <?php if (oldValue('vaccination') == "Partially Completed") echo "selected"; ?>>Partially Completed</option>
                </select>

                <label>Description</label>
                <textarea 
                    name="description"
                    placeholder="Write a short description about the pet"
                    required><?php echo oldValue('description'); ?></textarea>

                <label>Pet Image</label>
                <input 
                    type="file" 
                    name="image"
                    accept="image/png, image/jpeg, image/jpg"
                >

                <button type="submit" class="btn">Add Pet</button>

            </form>

        </div>

    </div>
</section>

<script>
const breedData = {
    "Cat": [
        "Domestic Short Hair",
        "Domestic Long Hair",
        "Persian",
        "Siamese",
        "Maine Coon",
        "Bengal",
        "British Shorthair",
        "Ragdoll",
        "Scottish Fold",
        "American Shorthair",
        "Mixed Breed"
    ],
    "Dog": [
        "Mixed Breed",
        "Labrador Retriever",
        "Golden Retriever",
        "Poodle",
        "German Shepherd",
        "Shih Tzu",
        "Beagle",
        "Husky",
        "Terrier",
        "Corgi",
        "Pomeranian",
        "Chihuahua"
    ]
};

const speciesSelect = document.getElementById("species");
const breedInput = document.getElementById("breed");
const breedList = document.getElementById("breedList");

function loadBreedSuggestions(species) {
    breedList.innerHTML = "";

    if (species === "" || !breedData[species]) {
        breedInput.placeholder = "Select species first";
        return;
    }

    breedInput.placeholder = "Select from list or type breed manually";

    breedData[species].forEach(function(breed) {
        const option = document.createElement("option");
        option.value = breed;
        breedList.appendChild(option);
    });
}

speciesSelect.addEventListener("change", function () {
    breedInput.value = "";
    loadBreedSuggestions(this.value);
});

if (speciesSelect.value !== "") {
    loadBreedSuggestions(speciesSelect.value);
}
</script>

<script src="../js/ui-feedback.js"></script>

</body>
</html>