<?php
session_start();

$user_type = $_SESSION['user_type'] ?? "";

session_unset();
session_destroy();

session_start();

include("includes/flash.php");

setFlashMessage("success", "You have logged out successfully.");

if ($user_type == "staff") {
    header("Location: staff_login.php");
} else {
    header("Location: login.php");
}

exit();
?>