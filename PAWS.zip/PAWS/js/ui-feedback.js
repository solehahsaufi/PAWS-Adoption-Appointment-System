document.addEventListener("DOMContentLoaded", function () {

    const confirmLinks = document.querySelectorAll("[data-confirm]");

    confirmLinks.forEach(function (link) {
        link.addEventListener("click", function (event) {
            event.preventDefault();

            const message = this.getAttribute("data-confirm");
            const url = this.getAttribute("href");

            showConfirmBox(message, function () {
                window.location.href = url;
            });
        });
    });

    const confirmForms = document.querySelectorAll("form[data-confirm-submit]");

    confirmForms.forEach(function (form) {
        form.addEventListener("submit", function (event) {

            if (!form.checkValidity()) {
                form.reportValidity();
                return;
            }

            if (form.dataset.confirmed === "true") {
                return true;
            }

            event.preventDefault();

            const message = form.getAttribute("data-confirm-submit");

            showConfirmBox(message, function () {
                form.dataset.confirmed = "true";
                form.requestSubmit();
            });
        });
    });
});

function showConfirmBox(message, confirmAction) {

    const overlay = document.createElement("div");
    overlay.className = "confirm-overlay";
    overlay.style.display = "flex";

    overlay.innerHTML = `
        <div class="confirm-box">
            <div class="popup-icon">?</div>
            <h3>Confirm Action</h3>
            <p>${message}</p>

            <div class="confirm-actions">
                <button type="button" class="btn confirm-cancel" id="cancelConfirm">Cancel</button>
                <button type="button" class="btn" id="proceedConfirm">Confirm</button>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);

    document.getElementById("cancelConfirm").addEventListener("click", function () {
        overlay.remove();
    });

    document.getElementById("proceedConfirm").addEventListener("click", function () {
        overlay.remove();
        confirmAction();
    });
}

function closeMessagePopup() {
    const popup = document.getElementById("messagePopup");

    if (popup) {
        popup.remove();
    }
}