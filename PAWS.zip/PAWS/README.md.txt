# PAWS Adoption Appointment System

PAWS Adoption Appointment System is a web-based booking with scheduling system developed for ICT600 Web Technology and Application group project.

## System Modules

### Adopter
- Register account
- Login
- Manage profile
- Browse available pets
- Book adoption appointment
- View appointment status
- Submit adoption application
- View application status

### Staff
- Staff login
- Manage pets
- Manage appointment requests
- View booking schedule
- Manage adoption applications
- Change staff password

## Technology Used

- HTML
- CSS
- JavaScript
- PHP
- MySQL
- XAMPP

## Installation Guide

1. Copy the PAWS folder into:

C:\xampp\htdocs\

2. Start Apache and MySQL in XAMPP.

3. Open phpMyAdmin.

4. Create a database named:

paws_db

5. Import the SQL file:

paws_db.sql

6. Open the system in browser:

http://localhost/PAWS/

## Staff Login

Username: staff  
Password: ICT600

## Notes

If database connection fails, check the database port in connection.php. Some computers use port 3306, while this project may use port 3308.