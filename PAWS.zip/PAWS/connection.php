<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = mysqli_connect(
    "127.0.0.1",
    "root",
    "",
    "paws_db",
    3308
);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>