<?php
session_start();

include("connection.php");
include("includes/flash.php");

$message = "";

function oldValue($field)
{
    return isset($_POST[$field]) ? htmlspecialchars($_POST[$field]) : "";
}

function cleanPhoneNumber($phone)
{
    return preg_replace("/[^0-9]/", "", $phone);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);

    $address = trim($_POST['address']);
    $state = trim($_POST['state']);
    $city = trim($_POST['city']);
    $postcode = trim($_POST['postcode']);

    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    $phone_digits = cleanPhoneNumber($phone);

    /*
        These columns already exist in database from previous address design.
        We keep them blank so old database structure will not cause error.
    */
    $unit_no = "";
    $building_name = "";
    $street = "";
    $area = "";

    if (
        $full_name == "" ||
        $email == "" ||
        $phone == "" ||
        $address == "" ||
        $state == "" ||
        $city == "" ||
        $postcode == "" ||
        $password == "" ||
        $confirm_password == ""
    ) {
        $message = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please write a correct email format. Example: name@example.com";
    } elseif (!preg_match("/^((010|012|013|014|016|017|018|019)[0-9]{7}|011[0-9]{8})$/", $phone_digits)) {
        $message = "Please write a correct Malaysian phone number. Example: 012-3456789 or 011-12345678.";
    } elseif (!preg_match("/^[0-9]{5}$/", $postcode)) {
        $message = "Please select a valid 5-digit postcode.";
    } elseif ($password != $confirm_password) {
        $message = "Password and confirm password do not match.";
    } elseif (strlen($password) < 6) {
        $message = "Password must be at least 6 characters.";
    } else {

        $phone = substr($phone_digits, 0, 3) . "-" . substr($phone_digits, 3);

        $full_address = $address . ", " . $postcode . " " . $city . ", " . $state;

        $check = "SELECT * FROM adopter WHERE email = ?";
        $stmt_check = mysqli_prepare($conn, $check);

        if (!$stmt_check) {
            die("SQL Prepare Error: " . mysqli_error($conn));
        }

        mysqli_stmt_bind_param($stmt_check, "s", $email);
        mysqli_stmt_execute($stmt_check);

        $check_result = mysqli_stmt_get_result($stmt_check);

        if (mysqli_num_rows($check_result) > 0) {
            $message = "This email is already registered. Please login instead.";
        } else {

            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $sql = "INSERT INTO adopter 
                    (full_name, email, phone, unit_no, building_name, street, area, postcode, city, state, password, address)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = mysqli_prepare($conn, $sql);

            if (!$stmt) {
                die("SQL Prepare Error: " . mysqli_error($conn));
            }

            mysqli_stmt_bind_param(
                $stmt,
                "ssssssssssss",
                $full_name,
                $email,
                $phone,
                $unit_no,
                $building_name,
                $street,
                $area,
                $postcode,
                $city,
                $state,
                $hashed_password,
                $full_address
            );

            if (mysqli_stmt_execute($stmt)) {
                setFlashMessage("success", "Registration successful! Please login to continue.");
                header("Location: login.php");
                exit();
            } else {
                die("SQL Execute Error: " . mysqli_stmt_error($stmt));
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register | PAWS</title>
    <link rel="stylesheet" href="css/dashboard.css">
</head>

<body>

<?php displayFlashMessage(); ?>

<div class="top-header">
    <div class="brand">
        <img src="images/paws-logo.png" alt="PAWS Logo">
        <span>Create Adopter Account</span>
    </div>

    <a href="index.php" class="header-link">Home</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <div class="form-card">
            <h2>Register Account</h2>

            <div class="notice-box">
                Create an adopter account to book appointments and submit adoption applications.
            </div>

            <?php
            if ($message != "") {
                echo "<div class='error-box'>$message</div>";
            }
            ?>

            <form method="POST" id="registerForm">

                <label>Full Name</label>
                <input 
                    type="text" 
                    name="full_name" 
                    placeholder="Enter your full name" 
                    value="<?php echo oldValue('full_name'); ?>"
                    required
                >

                <label>Email Address</label>
                <input 
                    type="email" 
                    name="email" 
                    id="email"
                    placeholder="Example: name@example.com" 
                    value="<?php echo oldValue('email'); ?>"
                    required
                >
                <small id="emailError" class="field-error"></small>

                <label>Phone Number</label>
                <input 
                    type="text" 
                    name="phone" 
                    id="phone"
                    placeholder="Example: 012-3456789 or 011-12345678" 
                    value="<?php echo oldValue('phone'); ?>"
                    required
                >
                <small id="phoneError" class="field-error"></small>

                <label>Address</label>
                <textarea 
                    name="address" 
                    id="address"
                    placeholder="Example: No. 12, Jalan Melati 3, Taman Seri Indah"
                    required><?php echo oldValue('address'); ?></textarea>

                <label>State</label>
                <select name="state" id="state" required>
                    <option value="">Select state</option>
                    <option value="Johor">Johor</option>
                    <option value="Kedah">Kedah</option>
                    <option value="Kelantan">Kelantan</option>
                    <option value="Melaka">Melaka</option>
                    <option value="Negeri Sembilan">Negeri Sembilan</option>
                    <option value="Pahang">Pahang</option>
                    <option value="Perak">Perak</option>
                    <option value="Perlis">Perlis</option>
                    <option value="Pulau Pinang">Pulau Pinang</option>
                    <option value="Sabah">Sabah</option>
                    <option value="Sarawak">Sarawak</option>
                    <option value="Selangor">Selangor</option>
                    <option value="Terengganu">Terengganu</option>
                    <option value="Kuala Lumpur">Kuala Lumpur</option>
                    <option value="Labuan">Labuan</option>
                    <option value="Putrajaya">Putrajaya</option>
                </select>

                <label>City / District</label>
                <select name="city" id="city" required>
                    <option value="">Select state first</option>
                </select>

                <label>Postcode</label>
                <select name="postcode" id="postcode" required>
                    <option value="">Select city first</option>
                </select>
                <small id="postcodeError" class="field-error"></small>

                <label>Password</label>
                <input 
                    type="password" 
                    name="password" 
                    placeholder="Create password" 
                    minlength="6"
                    required
                >

                <label>Confirm Password</label>
                <input 
                    type="password" 
                    name="confirm_password" 
                    placeholder="Confirm password" 
                    minlength="6"
                    required
                >

                <button type="submit" class="btn">Register</button>

            </form>

            <p style="text-align:center; margin-top:18px;">
                Already have an account?
                <a href="login.php" style="color:#1d4ed8; font-weight:600;">Login here</a>
            </p>
        </div>

    </div>
</section>

<script>
const locationData = {
    "Selangor": {
        "Shah Alam": ["40000", "40100", "40200", "40300", "40400"],
        "Petaling Jaya": ["46000", "46100", "46200", "46300", "47400"],
        "Subang Jaya": ["47500", "47600"],
        "Klang": ["41000", "41100", "41200", "41300", "41400"],
        "Kajang": ["43000"],
        "Bangi": ["43650"],
        "Puchong": ["47100", "47110", "47120", "47130"],
        "Rawang": ["48000"],
        "Selayang": ["68100"],
        "Ampang": ["68000"],
        "Cyberjaya": ["63000"],
        "Dengkil": ["43800"],
        "Banting": ["42700"],
        "Kuala Selangor": ["45000"],
        "Sungai Buloh": ["47000"],
        "Seri Kembangan": ["43300"],
        "Semenyih": ["43500"]
    },

    "Kelantan": {
        "Kota Bharu": ["15000", "15100", "15200", "15300", "15400", "16100"],
        "Tanah Merah": ["17500"],
        "Pasir Mas": ["17000"],
        "Tumpat": ["16200"],
        "Bachok": ["16300"],
        "Machang": ["18500"],
        "Pasir Puteh": ["16800"],
        "Kuala Krai": ["18000"],
        "Gua Musang": ["18300"],
        "Jeli": ["17600"],
        "Rantau Panjang": ["17200"],
        "Wakaf Bharu": ["16250"]
    },

    "Johor": {
        "Johor Bahru": ["80000", "80100", "80200", "80300", "81200"],
        "Batu Pahat": ["83000"],
        "Muar": ["84000"],
        "Kluang": ["86000"],
        "Segamat": ["85000"],
        "Pontian": ["82000"],
        "Kota Tinggi": ["81900"],
        "Mersing": ["86800"],
        "Kulai": ["81000"],
        "Pasir Gudang": ["81700"]
    },

    "Kedah": {
        "Alor Setar": ["05000", "05100", "05200", "05300"],
        "Sungai Petani": ["08000"],
        "Kulim": ["09000"],
        "Jitra": ["06000"],
        "Langkawi": ["07000"],
        "Baling": ["09100"],
        "Pendang": ["06700"],
        "Yan": ["06900"],
        "Gurun": ["08300"]
    },

    "Melaka": {
        "Melaka Tengah": ["75000", "75100", "75200", "75300"],
        "Ayer Keroh": ["75450"],
        "Alor Gajah": ["78000"],
        "Jasin": ["77000"],
        "Masjid Tanah": ["78300"],
        "Merlimau": ["77300"]
    },

    "Negeri Sembilan": {
        "Seremban": ["70000", "70100", "70200", "70300"],
        "Port Dickson": ["71000"],
        "Nilai": ["71800"],
        "Bahau": ["72100"],
        "Kuala Pilah": ["72000"],
        "Tampin": ["73000"],
        "Rembau": ["71300"]
    },

    "Pahang": {
        "Kuantan": ["25000", "25100", "25200", "25300"],
        "Temerloh": ["28000"],
        "Bentong": ["28700"],
        "Raub": ["27600"],
        "Jerantut": ["27000"],
        "Pekan": ["26600"],
        "Maran": ["26500"],
        "Rompin": ["26800"]
    },

    "Perak": {
        "Ipoh": ["30000", "30100", "30200", "30300", "31400"],
        "Taiping": ["34000"],
        "Teluk Intan": ["36000"],
        "Sitiawan": ["32000"],
        "Lumut": ["32200"],
        "Kuala Kangsar": ["33000"],
        "Kampar": ["31900"],
        "Batu Gajah": ["31000"]
    },

    "Perlis": {
        "Kangar": ["01000"],
        "Arau": ["02600"],
        "Padang Besar": ["02100"],
        "Kuala Perlis": ["02000"]
    },

    "Pulau Pinang": {
        "George Town": ["10000", "10100", "10200", "10300", "10400"],
        "Butterworth": ["12000"],
        "Bukit Mertajam": ["14000"],
        "Bayan Lepas": ["11900"],
        "Balik Pulau": ["11000"],
        "Nibong Tebal": ["14300"],
        "Perai": ["13600"]
    },

    "Sabah": {
        "Kota Kinabalu": ["88000", "88100", "88200", "88300"],
        "Sandakan": ["90000"],
        "Tawau": ["91000"],
        "Lahad Datu": ["91100"],
        "Keningau": ["89000"],
        "Semporna": ["91300"],
        "Kudat": ["89050"]
    },

    "Sarawak": {
        "Kuching": ["93000", "93100", "93200", "93300"],
        "Miri": ["98000"],
        "Sibu": ["96000"],
        "Bintulu": ["97000"],
        "Limbang": ["98700"],
        "Sri Aman": ["95000"],
        "Sarikei": ["96100"]
    },

    "Terengganu": {
        "Kuala Terengganu": ["20000", "20100", "20200", "20300"],
        "Kuala Nerus": ["21300"],
        "Dungun": ["23000"],
        "Kemaman": ["24000"],
        "Marang": ["21600"],
        "Besut": ["22000"],
        "Setiu": ["22100"]
    },

    "Kuala Lumpur": {
        "Kuala Lumpur": ["50000", "50100", "50200", "50300", "50400"],
        "Cheras": ["56000"],
        "Setapak": ["53000"],
        "Wangsa Maju": ["53300"],
        "Bangsar": ["59000"],
        "Mont Kiara": ["50480"],
        "Kepong": ["52100"],
        "Sentul": ["51000"]
    },

    "Putrajaya": {
        "Putrajaya": ["62000", "62100", "62200", "62300", "62500"],
        "Presint 8": ["62250"],
        "Presint 9": ["62250"],
        "Presint 11": ["62300"]
    },

    "Labuan": {
        "Labuan": ["87000"],
        "Victoria": ["87000"]
    }
};

const selectedState = "<?php echo isset($_POST['state']) ? htmlspecialchars($_POST['state']) : ''; ?>";
const selectedCity = "<?php echo isset($_POST['city']) ? htmlspecialchars($_POST['city']) : ''; ?>";
const selectedPostcode = "<?php echo isset($_POST['postcode']) ? htmlspecialchars($_POST['postcode']) : ''; ?>";

const emailInput = document.getElementById("email");
const phoneInput = document.getElementById("phone");
const stateSelect = document.getElementById("state");
const citySelect = document.getElementById("city");
const postcodeSelect = document.getElementById("postcode");

const emailError = document.getElementById("emailError");
const phoneError = document.getElementById("phoneError");
const postcodeError = document.getElementById("postcodeError");

function validateEmailLive() {
    const email = emailInput.value.trim();
    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (email === "") {
        emailError.textContent = "";
        emailError.className = "field-error";
        emailInput.setCustomValidity("");
    } else if (!pattern.test(email)) {
        emailError.textContent = "Please write a correct email format. Example: name@example.com";
        emailError.className = "field-error";
        emailInput.setCustomValidity("Please write a correct email format.");
    } else {
        emailError.textContent = "";
        emailError.className = "field-error";
        emailInput.setCustomValidity("");
    }
}

function validatePhoneLive() {
    const phone = phoneInput.value.trim();
    const digits = phone.replace(/[^0-9]/g, "");
    const pattern = /^((010|012|013|014|016|017|018|019)[0-9]{7}|011[0-9]{8})$/;

    if (phone === "") {
        phoneError.textContent = "";
        phoneError.className = "field-error";
        phoneInput.setCustomValidity("");
    } else if (!pattern.test(digits)) {
        phoneError.textContent = "Please write a correct Malaysian phone number. Example: 012-3456789 or 011-12345678.";
        phoneError.className = "field-error";
        phoneInput.setCustomValidity("Please write a correct Malaysian phone number.");
    } else {
        phoneError.textContent = "";
        phoneError.className = "field-error";
        phoneInput.setCustomValidity("");
    }
}

function loadCities(stateName, cityToSelect = "") {
    citySelect.innerHTML = "";
    postcodeSelect.innerHTML = "<option value=''>Select city first</option>";

    if (stateName === "" || !locationData[stateName]) {
        citySelect.innerHTML = "<option value=''>Select state first</option>";
        return;
    }

    citySelect.innerHTML = "<option value=''>Select city / district</option>";

    Object.keys(locationData[stateName]).forEach(function(city) {
        const option = document.createElement("option");
        option.value = city;
        option.textContent = city;

        if (city === cityToSelect) {
            option.selected = true;
        }

        citySelect.appendChild(option);
    });

    if (cityToSelect !== "") {
        loadPostcodes(stateName, cityToSelect, selectedPostcode);
    }
}

function loadPostcodes(stateName, cityName, postcodeToSelect = "") {
    postcodeSelect.innerHTML = "";

    if (
        stateName === "" ||
        cityName === "" ||
        !locationData[stateName] ||
        !locationData[stateName][cityName]
    ) {
        postcodeSelect.innerHTML = "<option value=''>Select city first</option>";
        return;
    }

    postcodeSelect.innerHTML = "<option value=''>Select postcode</option>";

    locationData[stateName][cityName].forEach(function(postcode) {
        const option = document.createElement("option");
        option.value = postcode;
        option.textContent = postcode;

        if (postcode === postcodeToSelect) {
            option.selected = true;
        }

        postcodeSelect.appendChild(option);
    });
}

emailInput.addEventListener("input", validateEmailLive);
phoneInput.addEventListener("input", validatePhoneLive);

stateSelect.addEventListener("change", function () {
    loadCities(this.value);
});

citySelect.addEventListener("change", function () {
    loadPostcodes(stateSelect.value, this.value);
});

postcodeSelect.addEventListener("change", function () {
    if (postcodeSelect.value === "") {
        postcodeError.textContent = "Please select a postcode.";
        postcodeError.className = "field-error";
    } else {
        postcodeError.textContent = "";
        postcodeError.className = "field-error";
    }
});

if (selectedState !== "") {
    stateSelect.value = selectedState;
    loadCities(selectedState, selectedCity);

    if (selectedCity !== "") {
        loadPostcodes(selectedState, selectedCity, selectedPostcode);
    }
}

validateEmailLive();
validatePhoneLive();
</script>

<script src="js/ui-feedback.js"></script>

</body>
</html>