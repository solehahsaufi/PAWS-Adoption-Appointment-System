<?php
include("../includes/session.php");
checkStaff();
include("../connection.php");

date_default_timezone_set("Asia/Kuala_Lumpur");

$today = date("Y-m-d");
$day_name = date("l");

$all_slots = [
    "09:00" => "9:00 AM",
    "10:00" => "10:00 AM",
    "11:00" => "11:00 AM",
    "12:00" => "12:00 PM",
    "13:00" => "1:00 PM",
    "14:00" => "2:00 PM",
    "15:00" => "3:00 PM"
];

$sql = "SELECT appointment.*, 
               adopter.full_name, adopter.phone,
               pet.pet_name, pet.species, pet.breed
        FROM appointment
        JOIN adopter ON appointment.adopter_id = adopter.adopter_id
        JOIN pet ON appointment.pet_id = pet.pet_id
        WHERE appointment.appointment_date = ?
        AND appointment.status != 'Cancelled'
        ORDER BY appointment.appointment_time ASC";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $today);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$bookings = [];

while ($row = mysqli_fetch_assoc($result)) {
    $time_key = substr($row['appointment_time'], 0, 5);
    $bookings[$time_key] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Today's Booking Schedule | PAWS</title>
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>

<div class="top-header">
    <div class="brand">
        <img src="../images/paws-logo.png" alt="PAWS Logo">
        <span>Today's Booking Schedule</span>
    </div>
    <a href="dashboard.php" class="header-link">Back to Dashboard</a>
</div>

<section class="page-section">
    <div class="content-wrapper">

        <h2 class="page-title">Today's Booking Schedule</h2>
        <p class="page-subtitle">
            Date: <strong><?php echo date("d F Y"); ?></strong> |
            Day: <strong><?php echo $day_name; ?></strong>
        </p>

        <?php if ($day_name == "Wednesday") { ?>
            <div class="error-box">
                PAWS is closed every Wednesday. No appointment booking is available today.
            </div>
        <?php } else { ?>

        <div class="notice-box">
            <strong>Operation Hours:</strong><br>
            PAWS appointment booking is available from <strong>9:00 AM to 4:00 PM</strong>.
            Each slot represents one appointment session.
        </div>

        <div class="table-card">
            <table>
                <tr>
                    <th>Time Slot</th>
                    <th>Booking Status</th>
                    <th>Adopter</th>
                    <th>Phone</th>
                    <th>Pet</th>
                    <th>Appointment Status</th>
                    <th>Action</th>
                </tr>

                <?php foreach ($all_slots as $slot_time => $slot_label) { ?>

                <tr>
                    <td><strong><?php echo $slot_label; ?></strong></td>

                    <?php if (isset($bookings[$slot_time])) { 
                        $booking = $bookings[$slot_time];
                    ?>

                        <td>
                            <span class="status status-pending">Booked</span>
                        </td>

                        <td><?php echo htmlspecialchars($booking['full_name']); ?></td>

                        <td><?php echo htmlspecialchars($booking['phone']); ?></td>

                        <td>
                            <?php echo htmlspecialchars($booking['pet_name']); ?><br>
                            <small>
                                <?php echo htmlspecialchars($booking['species']); ?> -
                                <?php echo htmlspecialchars($booking['breed']); ?>
                            </small>
                        </td>

                        <td>
                            <?php
                            if ($booking['status'] == "Scheduled") {
                                echo "<span class='status status-pending'>Scheduled</span>";
                            } elseif ($booking['status'] == "Completed") {
                                echo "<span class='status status-approved'>Completed</span>";
                            } else {
                                echo htmlspecialchars($booking['status']);
                            }
                            ?>
                        </td>

                        <td>
                            <?php if ($booking['status'] == "Scheduled") { ?>

                                <a href="update_appointment_status.php?id=<?php echo $booking['appointment_id']; ?>&action=complete"
                                   class="btn btn-green"
                                   onclick="return confirm('Mark this appointment as completed?');">
                                   Complete
                                </a>

                                <a href="update_appointment_status.php?id=<?php echo $booking['appointment_id']; ?>&action=cancel"
                                   class="btn btn-red"
                                   onclick="return confirm('Cancel this appointment?');">
                                   Cancel
                                </a>

                            <?php } else { ?>

                                <span style="color:#6b7280;">No action</span>

                            <?php } ?>
                        </td>

                    <?php } else { ?>

                        <td>
                            <span class="status status-approved">Available</span>
                        </td>

                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                        <td><span style="color:#6b7280;">No booking</span></td>

                    <?php } ?>
                </tr>

                <?php } ?>

            </table>
        </div>

        <?php } ?>

    </div>
</section>

</body>
</html>