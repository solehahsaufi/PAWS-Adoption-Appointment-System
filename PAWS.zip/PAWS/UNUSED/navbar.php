<nav>

    <div class="logo">

        <h2>🐾 PAWS</h2>

    </div>

    <ul>

        <li><a href="/PAWS/index.php">Home</a></li>

        <li><a href="/PAWS/login.php">Login</a></li>

        <li><a href="/PAWS/register.php">Register</a></li>

    </ul>

</nav>