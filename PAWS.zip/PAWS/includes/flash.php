<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function setFlashMessage($type, $message)
{
    $_SESSION['flash_type'] = $type;
    $_SESSION['flash_message'] = $message;
}

function displayFlashMessage()
{
    if (isset($_SESSION['flash_message'])) {

        $type = $_SESSION['flash_type'];
        $message = $_SESSION['flash_message'];

        $title = "Message";
        $icon = "ℹ";

        if ($type == "success") {
            $title = "Success";
            $icon = "✓";
        } elseif ($type == "error") {
            $title = "Error";
            $icon = "!";
        } elseif ($type == "warning") {
            $title = "Warning";
            $icon = "!";
        }

        echo "
        <div class='popup-overlay' id='messagePopup'>
            <div class='popup-box popup-$type'>
                <div class='popup-icon'>$icon</div>
                <h3>$title</h3>
                <p>" . htmlspecialchars($message) . "</p>
                <button type='button' class='btn' onclick='closeMessagePopup()'>OK</button>
            </div>
        </div>
        ";

        unset($_SESSION['flash_type']);
        unset($_SESSION['flash_message']);
    }
}

?>