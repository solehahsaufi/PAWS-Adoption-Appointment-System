<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function checkAdopter()
{
    if (
        !isset($_SESSION['user_type']) ||
        $_SESSION['user_type'] != "adopter" ||
        !isset($_SESSION['adopter_id'])
    ) {
        header("Location: /PAWS/login.php");
        exit();
    }
}

function checkStaff()
{
    if (
        !isset($_SESSION['user_type']) ||
        $_SESSION['user_type'] != "staff" ||
        !isset($_SESSION['staff_id'])
    ) {
        header("Location: /PAWS/staff_login.php");
        exit();
    }
}
?>